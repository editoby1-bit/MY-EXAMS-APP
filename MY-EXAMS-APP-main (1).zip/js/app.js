/* ═══════════════════════════════════════════════════════════
   MY EXAMS APP — v2.1  (bug-fixed)
   WAEC · NECO · GCE · NABTEB
═══════════════════════════════════════════════════════════ */
(() => {

  const SK = {
    users:   'mea-users-v1',
    current: 'mea-current-v1',
    access:  'mea-access-v1',
    free:    'mea-free-lifetime-v1',   // lifetime trial counter
    streak:  'mea-streak-v1',
    tier:    'mea-tier-v1',            // 'student' | 'plus'
    class:   'mea-class-v1',           // { classCode, name, pin } — this device's class membership
    classAdmin: 'mea-class-admin-v1',  // { classCode, adminSecret, schoolName } — teacher device only
  };
  const FREE_TRIAL_LIMIT    = 10;   // lifetime questions, not daily
  const FREE_SNAP_LIMIT     = 3;    // lifetime snaps on free tier
  const EARLY_ADOPTER_PRICE = 200000; // ₦2,000 in kobo
  const STANDARD_PRICE      = 250000; // ₦2,500 in kobo
  const EARLY_ADOPTER_CAP   = 100;    // first 100 students

  const S = {
    currentUser: loadSafe(SK.current) || '',
    users:       loadSafe(SK.users, {}),
    hasAccess:   checkAccess(),
    tier:        loadSafe(SK.tier) || 'free',
    freeUsed:    getFreeUsed(),       // lifetime questions used on free tier
    freeSnaps:   getFreeSnaps(),      // lifetime snaps used on free tier
    streak:      loadSafe(SK.streak, { count:0, lastDate:'' }),
    exam:        'WAEC',
    year:        'random',
    bothMode:    'sections',
    section:     'A',
    sectionA:    [],
    sectionB:    [],            // 'random' or e.g. 2023
    subject:     '',
    mode:        '',
    type:        '',
    bothMode:    'sections',
    count:       20,
    questions:   [],
    answers:     [],
    flagged:     [],
    idx:         0,
    reviewMode:  false,
    showAnswer:  false,
    timerSecs:   0,
    timerId:     null,
    inSession:   false,
  };

  /* ── Element cache ── */
  const E = {};
  [
    'homeScreen','quizScreen','resultScreen',
    'studentNameInput','loginBtn','studentPill','streakDisplay',
    'subjectGrid','modeToggle','typeToggle','qCountSelect','durationSelect',
    'bothModeGroup','bothModeToggle',
    'sectionTabs','sectionTabA','sectionTabB','sectionACount','sectionBCount',
    'subjectSwitcher','subjectTabs',
    'startBtn','startBtnText',
    'historyList','clearHistoryBtn',
    'hStatSessions','hStatAvg','hStatBest','hStatQs',
    'paywallOverlay','paywallBadge','payBtn','payBtnPlus','payBtnYear','payBtnPlusYear','payBtnJamb','payBtnSchool',
    'accessCodeInput','redeemBtn','closePaywall',
    'earlyAdopterBanner','earlyAdopterCounter',
    'yearPillsContainer',
    'tabIndividual','tabJamb','tabSchool',
    'paywallIndividual','paywallJamb','paywallSchool',
    'sidebarToggle','sidebarBackdrop','quizSidebar','exitBtn',
    'sbStudent','sbSubject','sbMode','sbExam',
    'timerCard','timerDisplay','qhMobileTimer',
    'progressBar','progressFraction','progressSub',
    'qPills','submitQuizBtn',
    'qtypeBanner','qNumBadge','qSubjectTag','qYearTag','qPosIndicator','flagBtn',
    'objectivePanel','objectiveQuestion','optionsList','explanationArea','keyHint',
    'theoryPanel','theoryQuestion','markingScheme','toggleAnswerBtn','modelAnswer','examTipBox',
    'prevBtn','nextBtn','sectionJumpBtn',
    'resultEmoji','resultScore','resultGrade','resultSummary','resultStatsGrid','resultBreakdown',
    'reviewBtn','homeBtn','shareBtn','shareSessionBtn',
    'upgradeBar','upgradeBarBtn','upgradeBarText',
    'resultUpgradTeaser','rutBtn','rutTitle',
    'teaserToast','teaserToastText','teaserToastUpgrade','teaserToastClose',
    'aiExplainBtn','aiExplainTheoryBtn','aiExplainTeaser','meaAiPanel','meaAiClose','meaAiCredits','meaAiLoading','meaAiResponse','meaAiContent',
    'snapBtn','snapFileInput','snapCreditsBadge','snapActionRow','snapTip',
    'snapResultModal','snapResultClose','snapResultScore','snapResultGrade','snapResultPct',
    'snapHwWarning','snapFeedback','snapBreakdown','snapExaminerNote','snapResultDone',
    'snapProcessing',
  ].forEach(id => {
    const el = document.getElementById(id);
    if (!el) console.warn('Missing element:', id);
    E[id] = el;
  });

  /* ════════ INIT ════════ */
  function init() {
    buildSubjectGrid();
    bindEvents();
    restoreUser();
    refreshStats();
    renderHistory();
    renderStreak();
    countQuestions();
    initCommunityQuiz();
    initContestNotify();
    checkForSharedSession();
    refreshUpgradeBar();
    renderPlanBadge();
    // Clear any stale hash on load
    if (window.location.hash) {
      history.replaceState(null, '', window.location.pathname);
    }

    // Without this, a student who creates or joins a scheduled/ready
    // challenge and then just sits on some other screen would never find
    // out it started until they happened to reopen the modal or log in
    // again. This catches that regardless of which screen they're on.
    setInterval(() => {
      if (!S.currentUser) return;
      checkForStartedChallenges();
      checkScheduledChallengeReminders();
    }, 45000);

    // School & Class nav card + back buttons for the new dashboard screens
    const classNav = document.getElementById('dashTopBanner');
    if (classNav) classNav.addEventListener('click', () => openClassScreen());
    const cbb = document.getElementById('classBackBtn');
    if (cbb) cbb.addEventListener('click', () => showScreen('home'));
    const tbb = document.getElementById('teacherDashBackBtn');
    if (tbb) tbb.addEventListener('click', () => showScreen('home'));
    const pbb = document.getElementById('parentDashBackBtn');
    if (pbb) pbb.addEventListener('click', () => showScreen('home'));

    // Direct-link entry points for teacher/parent dashboards — e.g.
    // ?dash=teacher (this device's saved admin credentials, from Create
    // Class) or ?dash=parent&code=P-XXXXXXXX (works on ANY device — the
    // parent code itself is the credential).
    const dashParams = new URLSearchParams(location.search);
    const dashParam = dashParams.get('dash');
    if (dashParam === 'teacher') {
      const admin = loadSafe(SK.classAdmin);
      if (admin) openTeacherDashboard(admin.classCode, admin.adminSecret);
      else openClassScreen('teacher');
    } else if (dashParam === 'parent') {
      openParentDashboard(dashParams.get('code'));
    }
  }

  function countQuestions() {
    let t = 0;
    Object.values(EXAM_BANK).forEach(s => {
      t += (s.objective?.length||0) + (s.theory?.length||0);
    });
    if (E.hStatQs) E.hStatQs.textContent = t;
  }

  /* ════════ SUBJECT GRID ════════ */
  function buildSubjectGrid() {
    E.subjectGrid.innerHTML = '';
    Object.entries(SUBJECTS).forEach(([key, meta]) => {
      if (!EXAM_BANK[key]) return;
      const btn = document.createElement('button');
      btn.className = 'subject-btn';
      btn.dataset.subject = key;
      btn.innerHTML =
        `<span class="sub-icon">${meta.icon}</span>` +
        `<span class="sub-name">${meta.name}</span>` +
        `<span class="sub-count" data-subject-count="${key}">0Q</span>`;
      btn.addEventListener('click', () => pickSubject(key, btn));
      E.subjectGrid.appendChild(btn);
    });
    updateSubjectCounts(); // populate counts for current exam
  }

  function getExamCount(key) {
    const bank = EXAM_BANK[key];
    if (!bank) return 0;
    const examFilter = q => !q.exam || q.exam === S.exam;
    const obj = (bank.objective||[]).filter(examFilter).length;
    const th  = (bank.theory||[]).filter(examFilter).length;
    if (S.type === 'objective') return obj;
    if (S.type === 'theory')    return th;
    return obj + th;
  }

  /* ════════ EVENTS ════════ */
  function bindEvents() {
    E.loginBtn.addEventListener('click', loginStudent);
    E.studentNameInput.addEventListener('keydown', e => { if (e.key==='Enter') loginStudent(); });

    document.querySelectorAll('#examPillsContainer .exam-pill').forEach(p =>
      p.addEventListener('click', () => {
        document.querySelectorAll('#examPillsContainer .exam-pill').forEach(x => x.classList.remove('active'));
        p.classList.add('active');
        S.exam = p.dataset.exam;
        updateSubjectCounts();
      })
    );

    // Year pills
    document.querySelectorAll('#yearPillsContainer .year-pill').forEach(p =>
      p.addEventListener('click', () => {
        document.querySelectorAll('#yearPillsContainer .year-pill').forEach(x => x.classList.remove('active'));
        p.classList.add('active');
        S.year = p.dataset.year === 'random' ? 'random' : Number(p.dataset.year);
        updateSubjectCounts();
      })
    );

    E.modeToggle.querySelectorAll('.mode-btn').forEach(b =>
      b.addEventListener('click', () => {
        E.modeToggle.querySelectorAll('.mode-btn').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        S.mode = b.dataset.mode || '';
        E.durationSelect.disabled = (S.mode !== 'exam');
        refreshStartBtn();
      })
    );

    E.typeToggle.querySelectorAll('.mode-btn').forEach(b =>
      b.addEventListener('click', () => {
        E.typeToggle.querySelectorAll('.mode-btn').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        S.type = b.dataset.type || '';
        if (E.bothModeGroup) E.bothModeGroup.classList.toggle('hidden', S.type !== 'both');
        updateSubjectCounts();
        refreshStartBtn();
      })
    );

    E.qCountSelect.addEventListener('change', () => {
      S.count = E.qCountSelect.value === 'all' ? 'all' : Number(E.qCountSelect.value);
    });

    E.startBtn.addEventListener('click', startSession);
    E.clearHistoryBtn.addEventListener('click', clearHistory);

    E.payBtn.addEventListener('click', () => handlePayment('student', 'quarterly'));
    if (E.payBtnYear)     E.payBtnYear.addEventListener('click',     () => handlePayment('student', 'yearly'));
    if (E.payBtnPlus)     E.payBtnPlus.addEventListener('click',     () => handlePayment('plus', 'quarterly'));
    if (E.payBtnPlusYear) E.payBtnPlusYear.addEventListener('click', () => handlePayment('plus', 'yearly'));
    if (E.payBtnJamb)     E.payBtnJamb.addEventListener('click',     () => handlePayment('jamb', 'quarterly'));
    if (E.payBtnSchool)   E.payBtnSchool.addEventListener('click',   () => handleSchoolEnquiry());
    E.redeemBtn.addEventListener('click', redeemCode);
    E.closePaywall.addEventListener('click', () => E.paywallOverlay.classList.add('hidden'));

    E.exitBtn.addEventListener('click', confirmExit);
    E.submitQuizBtn.addEventListener('click', confirmSubmit);
    E.prevBtn.addEventListener('click', () => navigate(-1));
    E.nextBtn.addEventListener('click', () => navigate(1));
    if (E.sectionJumpBtn) E.sectionJumpBtn.addEventListener('click', () => {
      if (S.type === 'both' && S.bothMode === 'sections') {
        switchSection(S.section === 'A' ? 'B' : 'A');
      }
    });
    E.toggleAnswerBtn.addEventListener('click', toggleAnswer);
    E.flagBtn.addEventListener('click', toggleFlag);

    E.sidebarToggle.addEventListener('click', openSidebar);
    E.sidebarBackdrop.addEventListener('click', closeSidebar);

    E.reviewBtn.addEventListener('click', enterReview);
    E.homeBtn.addEventListener('click', goHome);
    E.shareBtn.addEventListener('click', shareApp);
    if (E.shareSessionBtn) E.shareSessionBtn.addEventListener('click', shareSession);

    // Upgrade bar
    if (E.upgradeBarBtn) E.upgradeBarBtn.addEventListener('click', () => showPaywall('upgrade'));

    // Results screen upgrade teaser
    if (E.rutBtn) E.rutBtn.addEventListener('click', () => showPaywall('upgrade'));

    // Teaser toast
    if (E.teaserToastUpgrade) E.teaserToastUpgrade.addEventListener('click', () => {
      hideTeaserToast();
      showPaywall('upgrade');
    });
    if (E.teaserToastClose) E.teaserToastClose.addEventListener('click', hideTeaserToast);

    // AI explain
    if (E.aiExplainBtn)       E.aiExplainBtn.addEventListener('click', () => triggerMeaAI('objective'));
    if (E.aiExplainTheoryBtn) E.aiExplainTheoryBtn.addEventListener('click', () => triggerMeaAI('theory'));
    if (E.aiExplainTeaser)    E.aiExplainTeaser.addEventListener('click', () => {
      showInfoToast('Teach Me is only available in Practice Mode or when reviewing your results.');
    });
    if (E.meaAiClose)         E.meaAiClose.addEventListener('click', () => E.meaAiPanel?.classList.add('hidden'));

    // Snap and mark
    if (E.snapBtn)        E.snapBtn.addEventListener('click', triggerSnap);
    if (E.snapFileInput)  E.snapFileInput.addEventListener('change', handleSnapFile);
    if (E.snapResultClose) E.snapResultClose.addEventListener('click', () => E.snapResultModal.classList.add('hidden'));
    if (E.snapResultDone)  E.snapResultDone.addEventListener('click', () => E.snapResultModal.classList.add('hidden'));

    // Both mode toggle
    if (E.bothModeToggle) {
      E.bothModeToggle.querySelectorAll('.mode-btn').forEach(b =>
        b.addEventListener('click', () => {
          E.bothModeToggle.querySelectorAll('.mode-btn').forEach(x => x.classList.remove('active'));
          b.classList.add('active');
          S.bothMode = b.dataset.bothmode;
        })
      );
    }

    // Section tab clicks
    if (E.sectionTabA) E.sectionTabA.addEventListener('click', () => switchSection('A'));
    if (E.sectionTabB) E.sectionTabB.addEventListener('click', () => switchSection('B'));

    document.addEventListener('keydown', onKey);

    window.addEventListener('beforeunload', e => {
      if (S.inSession && S.mode === 'exam' && !S.reviewMode) {
        e.preventDefault(); e.returnValue = '';
      }
    });

    // Back button — clean single implementation
    // Back button — hash-based approach works reliably on Chrome mobile/PC and Firefox
    let _backLastPress = 0;

    window.addEventListener('hashchange', () => {
      // Challenge modal open — back button navigates its panels instead of
      // whatever the quiz-exit logic below would otherwise do.
      const modalEl = document.getElementById('quizChallengeModal');
      if (modalEl && !modalEl.classList.contains('hidden')) {
        if (_qcModalPanelHistory.length > 0) {
          window.location.hash = 'mea-challenge'; // stay armed for another back press
          const prev = _qcModalPanelHistory.pop();
          showQcPanel(prev, true);
        } else {
          clearInterval(_waitingRoomTimer);
          clearInterval(_waitingRoomCountdownTicker);
          modalEl.classList.add('hidden');
          history.replaceState(null, '', window.location.pathname);
        }
        return;
      }

      const quizActive   = document.getElementById('quizScreen')?.classList.contains('active');
      const resultActive = document.getElementById('resultScreen')?.classList.contains('active');

      if (!quizActive && !resultActive) return;

      // Immediately restore the hash so back button stays active
      if (quizActive)   window.location.hash = 'quiz';
      if (resultActive) window.location.hash = 'result';

      if (resultActive) {
        goHome();
        return;
      }

      // Double-back to exit
      const now = Date.now();
      if (now - _backLastPress < 3000) {
        _backLastPress = 0;
        hideBackWarningToast();
        confirmExit();
      } else {
        _backLastPress = now;
        showBackWarningToast();
      }
    });
  }

  /* ════════ KEYBOARD ════════ */
  function onKey(e) {
    if (!E.quizScreen.classList.contains('active')) return;
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    const q = S.questions[S.idx];
    switch(e.key) {
      case 'ArrowRight': case 'ArrowDown': e.preventDefault(); navigate(1); break;
      case 'ArrowLeft':  case 'ArrowUp':   e.preventDefault(); navigate(-1); break;
      case '1': case '2': case '3': case '4':
        if (!S.reviewMode && q?._type==='objective' && S.answers[S.idx]===null) {
          const i = Number(e.key)-1;
          if (i < (q.options?.length||0)) { S.answers[S.idx]=i; renderQ(); }
        }
        break;
      case 'f': case 'F': toggleFlag(); break;
      case 'Escape':
        if (E.quizSidebar.classList.contains('sidebar-open')) closeSidebar();
        else confirmExit();
        break;
    }
  }

  /* ════════ LOGIN / USER ════════ */
  function loginStudent() {
    const name = E.studentNameInput.value.trim().replace(/\s+/g,' ');
    if (!name) {
      E.studentNameInput.focus();
      E.studentNameInput.style.borderColor = 'var(--red)';
      setTimeout(() => { E.studentNameInput.style.borderColor = ''; }, 1500);
      return;
    }
    if (!S.users[name]) S.users[name] = { history:[] };
    S.currentUser = name;
    saveSafe(SK.users, S.users);
    saveSafe(SK.current, name);
    tickStreak();
    renderUser();
    refreshStats();
    renderHistory();
    refreshStartBtn();
    refreshUpgradeBar();
    checkForStartedChallenges();
    checkScheduledChallengeReminders();
  }

  function restoreUser() {
    if (S.currentUser) {
      E.studentNameInput.value = S.currentUser;
      renderUser();
      renderHistory();
    }
    refreshStats();
    refreshUpgradeBar();
    checkForStartedChallenges();
    checkScheduledChallengeReminders();
  }

  function renderUser() {
    if (S.currentUser) {
      E.studentPill.textContent = '✓  ' + S.currentUser;
      E.studentPill.className = 'student-status active';
      updateFreeTrialIndicator();
    } else {
      E.studentPill.textContent = 'No student logged in';
      E.studentPill.className = 'student-status';
    }
  }

  /* ════════ STREAK ════════ */
  function tickStreak() {
    const today = todayStr();
    const prev  = new Date(Date.now()-86400000).toISOString().slice(0,10);
    if (S.streak.lastDate === today) return;
    S.streak.count = S.streak.lastDate === prev ? S.streak.count+1 : 1;
    S.streak.lastDate = today;
    saveSafe(SK.streak, S.streak);
    renderStreak();
  }

  function renderStreak() {
    if (!E.streakDisplay) return;
    const c = S.streak.count||0;
    if (c > 0) {
      E.streakDisplay.textContent = `🔥 ${c} day${c>1?'s':''}`;
      E.streakDisplay.style.display = 'inline-flex';
    } else {
      E.streakDisplay.style.display = 'none';
    }
  }

  /* ════════ SUBJECT SELECTION ════════ */
  function pickSubject(key, btn) {
    document.querySelectorAll('.subject-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    S.subject = key;
    refreshStartBtn();
  }

  function updateSubjectCounts() {
    document.querySelectorAll('.subject-btn').forEach(btn => {
      const key  = btn.dataset.subject;
      const bank = EXAM_BANK[key];
      if (!bank) { btn.disabled=true; return; }
      const hasObj = (bank.objective?.length||0) > 0;
      const hasTh  = (bank.theory?.length||0) > 0;
      const ok = S.type==='objective' ? hasObj
               : S.type==='theory'    ? hasTh
               : hasObj||hasTh;
      btn.disabled = !ok;
      btn.style.opacity = ok ? '' : '0.35';
      const n = getExamCount(key);
      const c = btn.querySelector('.sub-count');
      if (c) c.textContent = (n||'0')+'Q';
    });
    if (S.subject) {
      const active = document.querySelector('.subject-btn.active');
      if (!active || active.disabled) { S.subject=''; refreshStartBtn(); }
    }
  }

  function refreshStartBtn() {
    const hasSubject = Boolean(S.subject);
    const hasUser    = Boolean(S.currentUser);

    if (!hasUser) {
      E.startBtn.disabled = false; // keep enabled — clicking will prompt to login
      E.startBtnText.textContent = 'Login above to start';
    } else if (!hasSubject) {
      E.startBtn.disabled = true;
      E.startBtnText.textContent = 'Select a subject to begin';
    } else {
      E.startBtn.disabled = false;
      E.startBtnText.textContent =
        `${S.mode==='exam' ? 'Start Exam' : 'Start Practice'} — ${SUBJECTS[S.subject]?.name||S.subject}`;
    }
  }

  /* ════════ START SESSION ════════ */
  function startSession() {
    // Must be logged in — give clear feedback if not
    if (!S.currentUser) {
      E.studentNameInput.focus();
      E.studentNameInput.style.borderColor = 'var(--red)';
      setTimeout(() => { E.studentNameInput.style.borderColor = ''; }, 2000);
      E.studentPill.textContent = '⚠ Please enter your name above first';
      E.studentPill.style.color = 'var(--red)';
      setTimeout(() => {
        E.studentPill.style.color = '';
        renderUser();
      }, 2500);
      return;
    }

    // Validate mode and type with gentle popups
    if (!S.mode) {
      showGentleInlinePopup('👇 Please select a Mode first', document.getElementById('modeToggle'));
      return;
    }
    if (!S.type) {
      showGentleInlinePopup('👇 Please select a Type first', document.getElementById('typeToggle'));
      return;
    }

    // Must have subject
    if (!S.subject) {
      showGentleInlinePopup('👇 Please select a Subject first', document.getElementById('subjectGrid'));
      return;
    }

    // Paywall — lifetime trial check
    if (!S.hasAccess && S.freeUsed >= FREE_TRIAL_LIMIT) {
      showPaywall('trial');
      return;
    }

    const bank = EXAM_BANK[S.subject];
    if (!bank) { alert('Subject data not found. Please try another.'); return; }

    // Filter by exam AND year (random = all years)
    const examFilter = q => (!q.exam || q.exam === S.exam) &&
                            (S.year === 'random' || !q.year || q.year === S.year);

    // Helper to get filtered pool for a type
    const getPool = (type) => {
      const raw = (bank[type]||[]);
      let qs = raw.filter(examFilter);
      if (!qs.length) qs = raw.filter(q => !q.exam || q.exam === S.exam);
      if (!qs.length) qs = [...raw];
      return shuffle(qs).map(q => ({...q, _type: type === 'objective' ? 'objective' : 'theory'}));
    };

    let pool = [];
    if (S.type === 'objective') {
      pool = getPool('objective');
    } else if (S.type === 'theory') {
      pool = getPool('theory');
    } else if (S.type === 'both' && S.bothMode === 'sections') {
      // Sections mode — keep pools separate, start with Section A
      S.sectionA = getPool('objective').slice(0, S.count);
      S.sectionB = getPool('theory').slice(0, Math.max(3, Math.ceil(S.count * 0.2)));
      S.section  = 'A';
      pool = [...S.sectionA];
    } else {
      // Mixed mode — interleave objectives and theory
      const objQs = getPool('objective');
      const thQs  = getPool('theory');
      pool = [...objQs, ...thQs];
    }

    if (!pool.length) {
      alert('No questions available for this selection. Try a different subject or type.');
      return;
    }

    const n = S.count === 'all' ? pool.length : Math.min(Number(S.count), pool.length);
    S.questions  = pool.slice(0, n);
    S.answers    = new Array(n).fill(null);
    S.flagged    = new Array(n).fill(false);
    S.qTimings   = new Array(n).fill(null);
    S.idx        = 0;
    S.reviewMode = false;
    S.showAnswer = false;
    S.inSession  = true;

    // Timer — read from E.durationSelect (was the v1 bug)
    if (S.timerId) { clearInterval(S.timerId); S.timerId = null; }
    if (S.mode === 'exam') {
      const raw  = E.durationSelect.value;
      const mins = raw === 'auto' ? n : (parseInt(raw) || n);
      S.timerSecs = mins * 60;
      E.timerCard.style.display = 'block';
      if (E.qhMobileTimer) E.qhMobileTimer.classList.remove('hidden');
      runTimer();
    } else {
      S.timerSecs = 0;
      E.timerCard.style.display = 'none';
      if (E.qhMobileTimer) E.qhMobileTimer.classList.add('hidden');
    }

    // Count free usage — lifetime, per session start
    if (!S.hasAccess) {
      S.freeUsed++;
      saveSafe(SK.free, { n: S.freeUsed });
      updateFreeTrialIndicator();
    }

    E.sbStudent.textContent = S.currentUser;
    E.sbSubject.textContent = SUBJECTS[S.subject]?.name || S.subject;
    E.sbMode.textContent    = S.mode === 'exam' ? 'Exam Mode' : 'Practice';
    E.sbExam.textContent    = S.exam;

    buildPills();
    renderQ();
    showScreen('quiz');
    if (window._collapseContest) window._collapseContest();
  }
  function runTimer() {
    tickClock();
    S.timerId = setInterval(() => {
      S.timerSecs--;
      tickClock();
      if (S.timerSecs <= 0) {
        clearInterval(S.timerId); S.timerId = null;
        finishSession(true);
      }
    }, 1000);
  }

  function tickClock() {
    const t = Math.max(S.timerSecs, 0);
    const display = `${pad(Math.floor(t/60))}:${pad(t%60)}`;
    const urgent = S.mode==='exam' && S.timerSecs>0 && S.timerSecs<300;
    E.timerDisplay.textContent = display;
    E.timerDisplay.classList.toggle('urgent', urgent);
    if (E.qhMobileTimer) {
      E.qhMobileTimer.textContent = '⏱ ' + display;
      E.qhMobileTimer.classList.toggle('urgent', urgent);
    }
  }

  function pad(n) { return String(n).padStart(2,'0'); }

  /* ════════ SUBJECT SWITCHER (multi-subject challenges) ════════ */
  function buildSubjectSwitcher() {
    if (!E.subjectTabs) return;
    E.subjectTabs.innerHTML = '';
    (S.subjects || []).forEach((subject, i) => {
      const range = (S.subjectRanges || {})[subject];
      if (!range) return;
      const btn = document.createElement('button');
      btn.className = 'section-tab' + (i === 0 ? ' active' : '');
      btn.dataset.subject = subject;
      btn.innerHTML = `<span class="section-tab-label">${safe(SUBJECTS[subject]?.name || subject)}</span>`;
      btn.addEventListener('click', () => jumpToSubject(subject));
      E.subjectTabs.appendChild(btn);
    });
  }

  function jumpToSubject(subject) {
    const range = (S.subjectRanges || {})[subject];
    if (!range) return;
    S.idx = range.start;
    renderQ();
  }

  function syncSubjectTabs() {
    if (!E.subjectTabs || E.subjectSwitcher?.classList.contains('hidden')) return;
    const q = S.questions[S.idx];
    const activeSubject = q?.sourceSubject;
    E.subjectTabs.querySelectorAll('.section-tab').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.subject === activeSubject);
    });
  }

  /* ════════ FLAG ════════ */
  function toggleFlag() {
    if (S.reviewMode) return;
    S.flagged[S.idx] = !S.flagged[S.idx];
    syncFlagBtn();
    syncPills();
  }

  function syncFlagBtn() {
    const on = S.flagged[S.idx];
    E.flagBtn.textContent = on ? '🚩 Flagged' : '🏳 Flag';
    E.flagBtn.classList.toggle('flag-on', on);
  }

  /* ════════ PILLS ════════ */
  function buildPills() {
    E.qPills.innerHTML = '';
    S.questions.forEach((q, i) => {
      const b = document.createElement('button');
      b.className = 'qpill' + (q._type==='theory' ? ' theory-pill' : '');
      b.textContent = i+1;
      b.title = `Q${i+1} · ${q._type==='theory'?'Theory':'Obj'}${q.year?' · '+q.year:''}`;
      b.addEventListener('click', () => {
        S.idx = i;
        closeSidebar();
        renderQ();
        // Trigger teaser if free user has reached question 5
        if (!S.hasAccess && i >= 4 && !S.reviewMode) {
          setTimeout(showTeaserToast, 1500);
        }
      });
      E.qPills.appendChild(b);
    });
    syncPills();
  }

  function syncPills() {
    E.qPills.querySelectorAll('.qpill').forEach((p, i) => {
      p.classList.toggle('p-current',  i===S.idx);
      p.classList.toggle('p-answered', S.answers[i]!==null);
      p.classList.toggle('p-flagged',  S.flagged[i]);
    });
    const done  = S.answers.filter(a => a!==null).length;
    const total = S.questions.length;
    E.progressBar.style.width  = total ? `${(done/total)*100}%` : '0%';
    E.progressFraction.textContent = `${S.idx+1} / ${total}`;
    E.progressSub.textContent      = `${done} of ${total} answered`;
  }

  /* ════════ RENDER QUESTION ════════ */
  function renderQ() {
    const q   = S.questions[S.idx];
    const ans = S.answers[S.idx];
    const obj = q._type === 'objective';

    // Track time student arrives at this question
    if (!S.qTimings[S.idx]) S.qTimings[S.idx] = { start: Date.now(), answered: null };
    else if (!S.qTimings[S.idx].start) S.qTimings[S.idx].start = Date.now();

    // Update section tabs if in sections mode
    if (S.type === 'both' && S.bothMode === 'sections') {
      if (E.sectionTabs) E.sectionTabs.classList.remove('hidden');
      if (E.sectionTabA) E.sectionTabA.classList.toggle('active', S.section === 'A');
      if (E.sectionTabB) E.sectionTabB.classList.toggle('active', S.section === 'B');
      if (E.sectionACount) E.sectionACount.textContent = S.sectionA.length + 'Q';
      if (E.sectionBCount) E.sectionBCount.textContent = S.sectionB.length + 'Q';
    } else {
      if (E.sectionTabs) E.sectionTabs.classList.add('hidden');
    }

    syncSubjectTabs();

    // Section jump button — always visible in sections mode
    if (E.sectionJumpBtn) {
      const inSections = S.type === 'both' && S.bothMode === 'sections';
      E.sectionJumpBtn.classList.toggle('hidden', !inSections);
      if (inSections) {
        E.sectionJumpBtn.textContent = S.section === 'A' ? '📋 Go to Section B →' : '📋 Go to Section A ←';
      }
    }

    E.qNumBadge.textContent     = `Q${S.idx+1}`;
    E.qSubjectTag.textContent   = SUBJECTS[S.subject]?.name || S.subject;
    E.qYearTag.textContent      = [q.exam||S.exam, q.year].filter(Boolean).join(' · ');
    E.qPosIndicator.textContent = `${S.idx+1} of ${S.questions.length}`;

    E.qtypeBanner.textContent = obj ? 'Objective Question' : 'Theory / Essay Question';
    E.qtypeBanner.className   = `qtype-banner ${obj?'obj':'theory'}`;

    // Teach Me only during Practice Mode or when reviewing results — never
    // during a live, timed Exam Mode session (would leak the answer to a
    // question you're being tested on). During exam mode, show a small,
    // inert teaser instead that just explains when it'll be available.
    const inPracticeOrReview = S.mode === 'practice' || S.reviewMode;
    if (E.aiExplainBtn)       E.aiExplainBtn.classList.toggle('hidden', !S.currentUser || !obj || !inPracticeOrReview);
    if (E.aiExplainTheoryBtn) E.aiExplainTheoryBtn.classList.toggle('hidden', !S.currentUser || obj || !inPracticeOrReview);
    if (E.aiExplainTeaser)    E.aiExplainTeaser.classList.toggle('hidden', !S.currentUser || inPracticeOrReview);
    if (E.meaAiPanel) E.meaAiPanel.classList.add('hidden');

    // Show snap button for all paid subscribers on theory questions
    if (E.snapTip) E.snapTip.classList.toggle('hidden', obj);
    document.getElementById('snapLockedIndicator')?.remove();
    if (S.hasAccess && !obj) {
      // Paid user on theory — show snap button
      updateSnapCreditsBadge();
      if (E.snapActionRow) { E.snapActionRow.style.display = 'flex'; E.snapActionRow.classList.remove('hidden'); }
      if (E.snapBtn) E.snapBtn.style.display = 'flex';
    } else if (!S.hasAccess && !obj) {
      // Free trial user on theory — show locked indicator
      if (E.snapActionRow) E.snapActionRow.style.display = 'none';
      const locked = document.createElement('div');
      locked.id = 'snapLockedIndicator';
      locked.className = 'snap-locked-indicator';
      locked.innerHTML = '<span class="sli-icon">📸</span><div class="sli-body"><span class="sli-title">Snap & Mark — Subscribe to Unlock</span><span class="sli-sub">Snap your theory answer and get marked by AI against the official scheme</span></div><button class="sli-btn" id="snapLockedBtn">Unlock →</button>';
      if (E.snapTip?.parentNode) E.snapTip.parentNode.insertBefore(locked, E.snapTip);
      document.getElementById('snapLockedBtn')?.addEventListener('click', () => showPaywall('upgrade'));
    } else {
      // Objective question — hide snap
      if (E.snapActionRow) E.snapActionRow.style.display = 'none';
    }

    E.objectivePanel.classList.toggle('hidden', !obj);
    E.theoryPanel.classList.toggle('hidden', obj);

    E.flagBtn.style.display = S.reviewMode ? 'none' : '';
    syncFlagBtn();

    if (obj) renderObjective(q, ans);
    else     renderTheory(q);

    E.prevBtn.disabled    = S.idx === 0;
    E.nextBtn.textContent = S.idx === S.questions.length-1
      ? (S.reviewMode ? '← Back to Results' : 'Finish ✓')
      : 'Next →';

    if (E.keyHint) {
      E.keyHint.style.display = obj && !S.reviewMode && ans===null ? 'block' : 'none';
    }

    syncPills();
  }

  /* ════════ OBJECTIVE ════════ */
  function renderObjective(q, ans) {
    E.objectiveQuestion.innerHTML = safe(q.question).replace(/\n/g,'<br>');
    E.optionsList.innerHTML = '';
    E.explanationArea.innerHTML = '';
    E.explanationArea.className = 'explanation-area';

    const locked  = S.reviewMode || (S.mode==='practice' && ans!==null);
    const showRes = S.reviewMode || (S.mode==='practice' && ans!==null);

    q.options.forEach((opt, i) => {
      const btn = document.createElement('button');
      btn.className = 'option-btn';
      btn.innerHTML =
        `<span class="opt-letter">${String.fromCharCode(65+i)}.</span>` +
        `<span class="opt-text">${safe(opt)}</span>`;

      if (showRes) {
        if (i===q.answer)                 btn.classList.add('opt-correct');
        if (i===ans && ans!==q.answer)    btn.classList.add('opt-wrong');
        if (i===ans && ans===q.answer)    btn.classList.add('opt-your-right');
      } else if (i===ans) {
        btn.classList.add('opt-selected');
      }

      btn.disabled = locked;
      if (!locked) {
        btn.addEventListener('click', () => {
          // Record answer timing
          if (!S.qTimings) S.qTimings = [];
          if (!S.qTimings[S.idx]) S.qTimings[S.idx] = { start: Date.now() };
          if (!S.qTimings[S.idx].answered) {
            S.qTimings[S.idx].answered = Date.now();
            S.qTimings[S.idx].duration = S.qTimings[S.idx].answered - (S.qTimings[S.idx].start || S.qTimings[S.idx].answered);
          }
          S.answers[S.idx]=i; renderQ();
        });
      }
      E.optionsList.appendChild(btn);
    });

    if (showRes && q.explanation) {
      const right = ans===q.answer;
      E.explanationArea.innerHTML =
        `<div class="exp-head ${right?'exp-right':'exp-wrong'}">` +
          (right ? '✅ Correct!' : `❌ Incorrect — Answer: <strong>${String.fromCharCode(65+q.answer)}</strong>`) +
        `</div>` +
        `<div class="exp-body">💡 ${safe(q.explanation)}</div>`;
      E.explanationArea.classList.add('visible');
    }
  }

  /* ════════ THEORY ════════ */
  function renderTheory(q) {
    E.theoryQuestion.innerHTML = safe(q.question).replace(/\n/g,'<br>');

    const total = q.totalMarks ||
      (q.markingScheme||[]).reduce((s,p) => s+(p.marks||0), 0);

    const isExam    = S.mode === 'exam';
    const inReview  = S.reviewMode;
    const snapped   = S.answers[S.idx] === 'snapped';
    const showFull  = inReview || snapped; // reveal everything after snap or in review

    if (isExam && !inReview) {
      // Exam mode: hide everything
      E.markingScheme.innerHTML = '';
      E.markingScheme.style.display = 'none';
      E.modelAnswer.classList.remove('visible');
      E.toggleAnswerBtn.style.display = 'none';
      E.examTipBox.style.display = 'none';
    } else if (!showFull) {
      // Practice mode — before snap: show only total marks, hide details
      E.markingScheme.style.display = '';
      E.markingScheme.innerHTML =
        `<div class="ms-head">` +
          `<span class="ms-title">📋 Marking Scheme</span>` +
          `<span class="ms-badge">${total} mark${total!==1?'s':''} available</span>` +
        `</div>` +
        `<div class="ms-snap-hint">📸 Snap your answer to see the marking scheme and model answer.</div>`;
      E.modelAnswer.classList.remove('visible');
      E.toggleAnswerBtn.style.display = 'none';
      E.examTipBox.style.display = 'none';
      S.showAnswer = false;
    } else {
      // Practice after snap, or review mode: show everything
      E.markingScheme.style.display = '';
      E.markingScheme.innerHTML =
        `<div class="ms-head">` +
          `<span class="ms-title">📋 Marking Scheme</span>` +
          `<span class="ms-badge">${total} mark${total!==1?'s':''}</span>` +
        `</div>` +
        `<div class="ms-list">` +
        (q.markingScheme||[]).map((pt,i) =>
          `<div class="ms-pt">` +
            `<span class="ms-n">${i+1}</span>` +
            `<span class="ms-txt">${safe(pt.point)}</span>` +
            `<span class="ms-mk">${pt.marks}mk</span>` +
          `</div>`
        ).join('') +
        `</div>`;

      E.modelAnswer.innerHTML = q.modelAnswer
        ? q.modelAnswer.split('\n').map(l =>
            l.trim()==='' ? '<br>' : `<p>${safe(l)}</p>`
          ).join('')
        : '<p><em>No model answer available.</em></p>';

      const showAns = inReview || S.showAnswer;
      E.modelAnswer.classList.toggle('visible', showAns);
      E.toggleAnswerBtn.style.display = '';
      E.toggleAnswerBtn.textContent = showAns ? '🙈 Hide Model Answer' : '📄 Show Model Answer';
      S.showAnswer = showAns;

      if (q.examTip) {
        E.examTipBox.innerHTML =
          `<div class="tip-head">⚡ Examiner's Tip</div>` +
          `<div class="tip-body">${safe(q.examTip)}</div>`;
        E.examTipBox.style.display = 'block';
      } else {
        E.examTipBox.style.display = 'none';
      }
    }

    // Don't auto-mark as seen — only snap counts as an attempt in practice mode
  }

  function toggleAnswer() {
    S.showAnswer = !S.showAnswer;
    E.modelAnswer.classList.toggle('visible', S.showAnswer);
    E.toggleAnswerBtn.textContent = S.showAnswer ? '🙈 Hide Model Answer' : '📄 Show Model Answer';
  }

  /* ════════ NAVIGATE ════════ */
  function navigate(dir) {
    if (dir>0 && S.idx===S.questions.length-1) {
      if (S.reviewMode) { showScreen('result'); return; }
      // Sections mode end of Section A — offer Section B before submit
      if (S.type === 'both' && S.bothMode === 'sections') {
        if (S.section === 'A' && S.sectionB.length > 0) {
          showSectionEndChoice('A');
          return;
        }
        if (S.section === 'B') {
          showSectionEndChoice('B');
          return;
        }
      }
      confirmSubmit();
      return;
    }
    S.idx = Math.max(0, Math.min(S.questions.length-1, S.idx+dir));
    S.showAnswer = S.reviewMode;
    closeSidebar();
    renderQ();
    // Show teaser toast at question 5 for free users
    if (!S.hasAccess && S.idx === 4 && !S.reviewMode) {
      setTimeout(showTeaserToast, 1500);
    }
    // Section B nudge — Both/Sections mode, on question 5 of Section A
    if (S.type === 'both' && S.bothMode === 'sections' && S.section === 'A' && S.idx === 4 && !S.reviewMode) {
      setTimeout(showSectionBNudge, 2000);
    }
  }

  /* ════════ SUBMIT ════════ */
  function confirmSubmit() {
    if (S.reviewMode) { showScreen('result'); return; }
    const unanswered = S.answers.filter((a,i) =>
      S.questions[i]._type==='objective' && a===null
    ).length;
    if (unanswered > 0) {
      if (!confirm(`${unanswered} question${unanswered>1?'s':''} unanswered. Submit anyway?`)) return;
    }
    finishSession(false);
  }

  /* ════════ FINISH ════════ */
  function finishSession(timeout=false) {
    if (S.timerId) { clearInterval(S.timerId); S.timerId=null; }
    S.inSession = false;

    const objQs   = S.questions.filter(q => q._type==='objective');
    const correct = objQs.filter(q => S.answers[S.questions.indexOf(q)]===q.answer).length;
    const wrong   = objQs.filter(q => {
      const a = S.answers[S.questions.indexOf(q)];
      return a!==null && a!=='seen' && a!==q.answer;
    }).length;
    const skipped = objQs.filter(q => S.answers[S.questions.indexOf(q)]===null).length;
    const thCount = S.questions.filter(q => q._type==='theory').length;
    const total   = objQs.length;
    const pct     = total>0 ? Math.round((correct/total)*100) : null;
    const flags   = S.flagged.filter(Boolean).length;

    const rec = {
      student:S.currentUser, subject:SUBJECTS[S.subject]?.name||S.subject,
      exam:S.exam, mode:S.mode, type:S.type,
      total, correct, wrong, skipped, thCount, pct, flags,
      date: new Date().toLocaleString(), timeout,
    };

    if (!S.users[S.currentUser]) S.users[S.currentUser]={history:[]};
    S.users[S.currentUser].history.unshift(rec);
    S.users[S.currentUser].history = S.users[S.currentUser].history.slice(0,60);
    saveSafe(SK.users, S.users);

    paintResults(rec);
    refreshStats();
    renderHistory();
    showScreen('result');
    if (window._collapseContest) window._collapseContest();
    S._timingAnalysis = calcTimingAnalysis();
    setTimeout(renderTimingCard, 150);

    // Store for session sharing
    _lastResult    = rec;
    _lastQuestions = [...S.questions];
    _lastAnswers   = [...S.answers];

    // Captured before saveChallengeScore runs — it clears S._challengeCode
    // synchronously as one of its first lines.
    const wasChallenge = !!S._challengeCode;

    // Save challenge score if this was a challenge session
    if (S._challengeCode && total > 0) {
      saveChallengeScore(correct, total);
    }

    // Best-effort report to the class dashboard (no-op if this device
    // hasn't joined a class). Only objective questions are auto-graded
    // here, so "missed" only ever covers those.
    if (total > 0) {
      const missed = objQs
        .filter(q => {
          const a = S.answers[S.questions.indexOf(q)];
          return a !== null && a !== 'seen' && a !== q.answer;
        })
        .map(q => q.id).filter(Boolean);
      recordClassSession({
        subject: SUBJECTS[S.subject]?.name || S.subject,
        exam: S.exam,
        mode: wasChallenge ? 'challenge' : 'practice',
        score: correct, total, missed,
      });
    }
  }

  /* ════════ SCHOOL / PARENT DASHBOARDS ════════
     A student joins a class with a class code + a 4-6 digit PIN they pick
     (stops another student claiming their name). Every completed session
     (practice, exam, or challenge) reports to /api/dashboard — best-effort,
     never blocks the student's own result screen. A parent link is a
     read-only code the student's own device generates for one child. */
  function getClassMembership() { return loadSafe(SK.class); }
  function saveClassMembership(m) { saveSafe(SK.class, m); }
  function clearClassMembership() { try { localStorage.removeItem(SK.class); } catch (e) {} }

  async function dashApi(action, body) {
    const res = await fetch(API_BASE + '/api/dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...body }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  async function recordClassSession({ subject, exam, mode, score, total, missed }) {
    const m = getClassMembership();
    if (!m) return;
    try {
      await dashApi('record_session', {
        classCode: m.classCode, name: m.name, pin: m.pin,
        subject, category: exam, mode, score, total, missed, timestamp: Date.now(),
      });
    } catch (e) { /* offline or class removed — not worth surfacing */ }
  }

  let _classTab = null; // 'student' | 'teacher' | 'parent' — remembered while classScreen is open

  function openClassScreen(tab) {
    showScreen('class');
    if (tab) _classTab = tab;
    renderClassScreen();
  }

  function renderClassScreen() {
    if (!_classTab) {
      _classTab = getClassMembership() ? 'student' : (loadSafe(SK.classAdmin) ? 'teacher' : 'student');
    }
    const body = document.getElementById('classBody');
    body.innerHTML = `
      <div class="mode-toggle" id="classTabBar" style="margin-bottom:1rem;">
        <button class="mode-btn ${_classTab === 'student' ? 'active' : ''}" data-tab="student">Student</button>
        <button class="mode-btn ${_classTab === 'teacher' ? 'active' : ''}" data-tab="teacher">Teacher</button>
        <button class="mode-btn ${_classTab === 'parent' ? 'active' : ''}" data-tab="parent">Parent</button>
      </div>
      <div id="classTabBody"></div>
    `;
    document.querySelectorAll('#classTabBar [data-tab]').forEach(btn => {
      btn.addEventListener('click', () => { _classTab = btn.dataset.tab; renderClassScreen(); });
    });
    const tabBody = document.getElementById('classTabBody');
    if (_classTab === 'teacher') renderTeacherTab(tabBody);
    else if (_classTab === 'parent') renderParentTab(tabBody);
    else renderStudentTab(tabBody);
  }

  /* ── Student tab: join a class, or manage membership + parent link ── */
  function renderStudentTab(body) {
    const m = getClassMembership();
    if (m) {
      body.innerHTML = `
        <div class="card" style="padding:1rem; margin-bottom:1rem;">
          <p style="margin:0 0 .35rem;">You're in a class</p>
          <p style="color:var(--text-dim,#8a94a6); font-size:.9rem;">Class code <b>${safe(m.classCode)}</b> · joined as <b>${safe(m.name)}</b></p>
          <p style="color:var(--text-dim,#8a94a6); font-size:.85rem;">Your practice sessions and challenges are now shared with your teacher's class dashboard.</p>
        </div>
        <div class="card" style="padding:1rem; margin-bottom:1rem;">
          <p style="margin:0 0 .5rem; font-weight:600;">Share progress with a parent</p>
          <p style="color:var(--text-dim,#8a94a6); font-size:.85rem; margin-bottom:.75rem;">Generates a link only they can use — nobody else's results.</p>
          <button class="btn-primary" id="genParentLinkBtn" style="width:100%;">Generate Parent Link</button>
          <div id="parentLinkOut" style="margin-top:.75rem;"></div>
        </div>
        <button class="btn-secondary" id="leaveClassBtn" style="width:100%;">Leave Class</button>
      `;
      document.getElementById('genParentLinkBtn').addEventListener('click', async () => {
        const btn = document.getElementById('genParentLinkBtn');
        btn.disabled = true; btn.textContent = 'Generating…';
        try {
          const { parentCode } = await dashApi('link_parent', { classCode: m.classCode, name: m.name, pin: m.pin });
          const url = `${location.origin}${location.pathname}?dash=parent&code=${encodeURIComponent(parentCode)}`;
          document.getElementById('parentLinkOut').innerHTML = `
            <input class="text-field" readonly value="${safe(parentCode)}" style="margin-bottom:.5rem;">
            <p style="font-size:.78rem; color:var(--text-dim,#8a94a6);">Or send this link: <br><span style="word-break:break-all;">${safe(url)}</span></p>`;
        } catch (e) {
          showInfoToast(e.message || 'Could not generate link');
        }
        btn.disabled = false; btn.textContent = 'Generate Parent Link';
      });
      document.getElementById('leaveClassBtn').addEventListener('click', () => {
        if (!confirm('Leave this class? You can rejoin any time with the class code.')) return;
        clearClassMembership();
        renderClassScreen();
      });
      return;
    }

    body.innerHTML = `
      <div class="card" style="padding:1rem;">
        <p style="margin:0 0 .5rem; font-weight:600;">Join your class</p>
        <p style="color:var(--text-dim,#8a94a6); font-size:.85rem; margin-bottom:1rem;">Ask your teacher for the class code. Pick a 4-6 digit PIN — this keeps your results only yours.</p>
        <input class="text-field" id="joinClassCode" placeholder="Class code (e.g. C-XXXXXX)" style="margin-bottom:.6rem;" autocapitalize="characters">
        <input class="text-field" id="joinClassName" placeholder="Your name" value="${S.currentUser ? safe(S.currentUser) : ''}" style="margin-bottom:.6rem;">
        <input class="text-field" id="joinClassPin" type="tel" placeholder="PIN (4-6 digits)" maxlength="6" style="margin-bottom:.8rem;">
        <button class="btn-primary" id="joinClassBtn" style="width:100%;">Join Class</button>
      </div>
    `;
    document.getElementById('joinClassBtn').addEventListener('click', async () => {
      const classCode = document.getElementById('joinClassCode').value.trim().toUpperCase();
      const name = document.getElementById('joinClassName').value.trim();
      const pin = document.getElementById('joinClassPin').value.trim();
      if (!classCode || !name || !/^\d{4,6}$/.test(pin)) { showInfoToast('Fill in class code, name, and a 4-6 digit PIN.'); return; }
      const btn = document.getElementById('joinClassBtn');
      btn.disabled = true; btn.textContent = 'Joining…';
      try {
        await dashApi('join_class', { classCode, name, pin });
        saveClassMembership({ classCode, name, pin });
        showInfoToast('Joined class!');
        renderClassScreen();
      } catch (e) {
        showInfoToast(e.message || 'Could not join class');
        btn.disabled = false; btn.textContent = 'Join Class';
      }
    });
  }

  /* ── Teacher tab: create a class, or log in to an existing one ── */
  function renderTeacherTab(body) {
    const admin = loadSafe(SK.classAdmin);
    if (admin) {
      body.innerHTML = `
        <div class="card" style="padding:1rem; margin-bottom:1rem;">
          <p style="margin:0 0 .35rem;">Logged in as admin</p>
          <p style="color:var(--text-dim,#8a94a6); font-size:.9rem;">${safe(admin.schoolName || 'Class')} · code <b>${safe(admin.classCode)}</b></p>
        </div>
        <button class="btn-primary" id="openTeacherDashBtn2" style="width:100%; margin-bottom:.6rem;">Open Teacher Dashboard</button>
        <button class="btn-secondary" id="teacherLogoutBtn" style="width:100%;">Log Out / Switch Class</button>
      `;
      document.getElementById('openTeacherDashBtn2').addEventListener('click', () => openTeacherDashboard(admin.classCode, admin.adminSecret));
      document.getElementById('teacherLogoutBtn').addEventListener('click', () => {
        try { localStorage.removeItem(SK.classAdmin); } catch (e) {}
        renderClassScreen();
      });
      return;
    }

    body.innerHTML = `
      <div class="card" style="padding:1rem; margin-bottom:1rem;">
        <p style="margin:0 0 .5rem; font-weight:600;">Log in to your class</p>
        <p style="color:var(--text-dim,#8a94a6); font-size:.85rem; margin-bottom:1rem;">Already created a class? Log back in with your class code and admin PIN.</p>
        <input class="text-field" id="loginClassCode" placeholder="Class code (e.g. C-XXXXXX)" style="margin-bottom:.6rem;" autocapitalize="characters">
        <input class="text-field" id="loginAdminPin" type="tel" placeholder="Admin PIN" maxlength="6" style="margin-bottom:.8rem;">
        <button class="btn-primary" id="teacherLoginBtn" style="width:100%;">Log In</button>
      </div>
      <div class="card" style="padding:1rem;">
        <p style="margin:0 0 .5rem; font-weight:600;">New here?</p>
        <p style="color:var(--text-dim,#8a94a6); font-size:.85rem; margin-bottom:1rem;">Create a class and get a code to share with your students.</p>
        <button class="btn-secondary" id="showCreateClassBtn" style="width:100%;">Create a Class</button>
        <div id="createClassForm" class="hidden" style="margin-top:1rem;">
          <input class="text-field" id="newSchoolName" placeholder="School / class name" style="margin-bottom:.6rem;">
          <input class="text-field" id="newAdminPin" type="tel" placeholder="Admin PIN (4-6 digits, for future logins)" maxlength="6" style="margin-bottom:.8rem;">
          <button class="btn-primary" id="createClassBtn" style="width:100%;">Create Class</button>
        </div>
      </div>
    `;

    document.getElementById('teacherLoginBtn').addEventListener('click', async () => {
      const classCode = document.getElementById('loginClassCode').value.trim().toUpperCase();
      const adminPin = document.getElementById('loginAdminPin').value.trim();
      if (!classCode || !/^\d{4,6}$/.test(adminPin)) { showInfoToast('Enter your class code and admin PIN.'); return; }
      const btn = document.getElementById('teacherLoginBtn');
      btn.disabled = true; btn.textContent = 'Logging in…';
      try {
        const { adminSecret, schoolName } = await dashApi('admin_login', { classCode, adminPin });
        saveSafe(SK.classAdmin, { classCode, adminSecret, schoolName });
        showInfoToast('Logged in!');
        openTeacherDashboard(classCode, adminSecret);
      } catch (e) {
        showInfoToast(e.message || 'Could not log in — check your class code and PIN.');
        btn.disabled = false; btn.textContent = 'Log In';
      }
    });

    document.getElementById('showCreateClassBtn').addEventListener('click', () => {
      document.getElementById('createClassForm').classList.toggle('hidden');
    });

    document.getElementById('createClassBtn').addEventListener('click', async () => {
      const schoolName = document.getElementById('newSchoolName').value.trim();
      const adminPin = document.getElementById('newAdminPin').value.trim();
      if (!schoolName || !/^\d{4,6}$/.test(adminPin)) { showInfoToast('Enter a class name and a 4-6 digit PIN.'); return; }
      const btn = document.getElementById('createClassBtn');
      btn.disabled = true; btn.textContent = 'Creating…';
      try {
        const { classCode, adminSecret } = await dashApi('create_class', { schoolName, adminPin });
        saveSafe(SK.classAdmin, { classCode, adminSecret, schoolName });
        const url = `${location.origin}${location.pathname}?dash=teacher`;
        document.getElementById('createClassForm').innerHTML = `
          <div class="card-inset" style="padding:1rem;">
            <p style="font-weight:600; margin-bottom:.5rem;">Class created! Share this code with your students:</p>
            <p style="font-size:1.4rem; font-weight:700; letter-spacing:.05em;">${safe(classCode)}</p>
            <p style="font-size:.8rem; color:var(--text-dim,#8a94a6); margin-top:.75rem;">Your teacher dashboard is saved on this device. Open it any time from: <br><span style="word-break:break-all;">${safe(url)}</span></p>
            <button class="btn-primary" style="width:100%; margin-top:1rem;" id="openTeacherDashBtn">Open Teacher Dashboard</button>
          </div>`;
        document.getElementById('openTeacherDashBtn').addEventListener('click', () => openTeacherDashboard(classCode, adminSecret));
      } catch (e) {
        showInfoToast(e.message || 'Could not create class');
        btn.disabled = false; btn.textContent = 'Create Class';
      }
    });
  }

  /* ── Parent tab: log in with a parent code ───────────────────── */
  function renderParentTab(body) {
    body.innerHTML = `
      <div class="card" style="padding:1rem;">
        <p style="margin:0 0 .5rem; font-weight:600;">Log in as a parent</p>
        <p style="color:var(--text-dim,#8a94a6); font-size:.85rem; margin-bottom:1rem;">Enter the parent code your child shared with you.</p>
        <input class="text-field" id="parentTabCode" placeholder="Parent code (e.g. P-XXXXXXXX)" style="margin-bottom:.8rem;" autocapitalize="characters">
        <button class="btn-primary" id="parentTabGoBtn" style="width:100%;">View Progress</button>
        <p id="parentTabErr" style="color:var(--red,#e55); font-size:.82rem; margin-top:.5rem;"></p>
      </div>
    `;
    document.getElementById('parentTabGoBtn').addEventListener('click', async () => {
      const code = document.getElementById('parentTabCode').value.trim().toUpperCase();
      if (!code) return;
      const btn = document.getElementById('parentTabGoBtn');
      btn.disabled = true; btn.textContent = 'Loading…';
      try {
        const data = await dashApi('get_parent_dashboard', { parentCode: code });
        showScreen('parentDash');
        renderParentDash(data);
      } catch (e) {
        document.getElementById('parentTabErr').textContent = e.message || 'Could not load — check the code.';
        btn.disabled = false; btn.textContent = 'View Progress';
      }
    });
  }

  /* ── Teacher dashboard (class-wide view) ─────────────────────── */
  function openTeacherDashboard(classCode, adminSecret) {
    showScreen('teacherDash');
    document.getElementById('teacherDashBody').innerHTML = `<p style="color:var(--text-dim,#8a94a6);">Loading class…</p>`;
    dashApi('get_class_dashboard', { classCode, adminSecret }).then(renderTeacherDash).catch(e => {
      document.getElementById('teacherDashBody').innerHTML = `<p style="color:var(--red,#e55);">${safe(e.message || 'Could not load dashboard')}</p>`;
    });
  }
  function renderTeacherDash(data) {
    const body = document.getElementById('teacherDashBody');
    if (!data.students.length) {
      body.innerHTML = `<p style="color:var(--text-dim,#8a94a6);">No students have joined <b>${safe(data.classCode)}</b> yet. Share the class code to get started.</p>`;
      return;
    }
    const sorted = [...data.students].sort((a, b) => (b.avgPct || 0) - (a.avgPct || 0));
    body.innerHTML = `
      <p style="color:var(--text-dim,#8a94a6); font-size:.85rem; margin-bottom:1rem;">${safe(data.schoolName || 'Class')} · ${data.students.length} student${data.students.length === 1 ? '' : 's'}</p>
      ${sorted.map(s => `
        <div class="card-inset" style="padding:1rem; margin-bottom:.85rem;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <strong>${safe(s.name)}</strong>
            <span style="font-weight:700; font-size:1.1rem;">${s.avgPct == null ? '—' : s.avgPct + '%'}</span>
          </div>
          <p style="font-size:.8rem; color:var(--text-dim,#8a94a6); margin:.35rem 0;">${s.sessionCount} session${s.sessionCount === 1 ? '' : 's'} · ${s.practiceCount || 0} practice · ${s.challengeCount || 0} challenge${(s.challengeCount || 0) === 1 ? '' : 's'}</p>
          ${renderSubjectBreakdown(s.bySubject)}
        </div>`).join('')}
    `;
  }
  function renderSubjectBreakdown(bySubject) {
    const entries = Object.entries(bySubject || {});
    if (!entries.length) return '';
    return `<div style="border-top:1px solid var(--border,#e2e2e2); margin-top:.5rem; padding-top:.5rem;">
      ${entries.sort((a, b) => a[1].avgPct - b[1].avgPct).map(([subj, d]) => `
        <div style="display:flex; justify-content:space-between; font-size:.82rem; padding:.2rem 0;">
          <span>${safe(subj)} ${d.weakQuestions.length ? '⚠️' : ''}</span>
          <span style="color:var(--text-dim,#8a94a6);">${d.avgPct}% avg · ${d.sessions}x</span>
        </div>`).join('')}
    </div>`;
  }

  /* ── Parent dashboard (single-child, read-only) ──────────────── */
  function openParentDashboard(prefillCode) {
    showScreen('parentDash');
    const body = document.getElementById('parentDashBody');
    body.innerHTML = `
      <input class="text-field" id="parentCodeInput" placeholder="Parent code (e.g. P-XXXXXXXX)" value="${prefillCode ? safe(prefillCode) : ''}" style="margin-bottom:.6rem;">
      <button class="btn-primary" id="parentCodeGoBtn" style="width:100%;">View Progress</button>
      <p id="parentCodeErr" style="color:var(--red,#e55); font-size:.82rem; margin-top:.5rem;"></p>`;
    const go = async () => {
      const code = document.getElementById('parentCodeInput').value.trim().toUpperCase();
      if (!code) return;
      const btn = document.getElementById('parentCodeGoBtn');
      btn.disabled = true; btn.textContent = 'Loading…';
      try {
        const data = await dashApi('get_parent_dashboard', { parentCode: code });
        renderParentDash(data);
      } catch (e) {
        document.getElementById('parentCodeErr').textContent = e.message || 'Could not load — check the code.';
        btn.disabled = false; btn.textContent = 'View Progress';
      }
    };
    document.getElementById('parentCodeGoBtn').addEventListener('click', go);
    if (prefillCode) go();
  }
  function renderParentDash(data) {
    const body = document.getElementById('parentDashBody');
    body.innerHTML = `
      <div class="card-inset" style="padding:1rem; margin-bottom:1rem;">
        <strong>${safe(data.name)}</strong>
        <p style="font-size:.85rem; color:var(--text-dim,#8a94a6);">${safe(data.schoolName || '')}</p>
        <div style="display:flex; gap:1.5rem; margin-top:.75rem;">
          <div><span style="font-weight:700; font-size:1.3rem;">${data.avgPct == null ? '—' : data.avgPct + '%'}</span><br><span style="font-size:.75rem; color:var(--text-dim,#8a94a6);">Average</span></div>
          <div><span style="font-weight:700; font-size:1.3rem;">${data.sessions.length}</span><br><span style="font-size:.75rem; color:var(--text-dim,#8a94a6);">Sessions</span></div>
        </div>
      </div>
      <div class="card-inset" style="padding:1rem; margin-bottom:1rem;">
        <p style="margin:0 0 .5rem; font-weight:600;">By subject</p>
        ${renderSubjectBreakdown(data.bySubject) || '<p style="color:var(--text-dim,#8a94a6); font-size:.85rem;">No sessions yet.</p>'}
      </div>
      <div class="card-inset" style="padding:1rem;">
        <p style="margin:0 0 .5rem; font-weight:600;">Recent sessions</p>
        ${data.sessions.slice(0, 15).map(s => `
          <div style="display:flex; justify-content:space-between; font-size:.82rem; padding:.3rem 0; border-bottom:1px solid var(--border,#e2e2e2);">
            <span>${safe(s.subject)} ${s.mode === 'challenge' ? '🏆' : ''}</span>
            <span style="color:var(--text-dim,#8a94a6);">${s.score}/${s.total} · ${new Date(s.at).toLocaleDateString()}</span>
          </div>`).join('') || '<p style="color:var(--text-dim,#8a94a6); font-size:.85rem;">No sessions yet.</p>'}
      </div>`;
  }

  /* ════════ RESULTS ════════ */
  function calcTimingAnalysis() {
    const timings = S.qTimings.filter(t => t && t.duration);
    if (timings.length < 3) return null;
    const durations = timings.map(t => t.duration);
    const avg = durations.reduce((a,b) => a+b, 0) / durations.length;
    const slow = S.questions
      .map((q,i) => ({ q, i, dur: S.qTimings[i]?.duration }))
      .filter(x => x.dur && x.dur > avg * 2 && x.dur > 30000) // >2x avg and >30s
      .slice(0, 3);
    const totalMs = S.qTimings.reduce((sum,t) => sum + (t?.duration||0), 0);
    const verdict = avg < 30000 ? 'Very fast — double-check your answers' :
                    avg < 60000 ? 'Good pace' :
                    avg < 90000 ? 'A little slow — try to speed up' :
                                  'Too slow — practise more to build speed';
    return { avg: Math.round(avg/1000), totalSec: Math.round(totalMs/1000), slow, verdict };
  }

  function paintResults(r) {
    const hasObj = r.pct!==null;
    const pct    = r.pct||0;
    const grade  = !hasObj?'Theory Study':pct>=75?'Distinction':pct>=60?'Credit':pct>=50?'Pass':'Below Pass';
    const emoji  = !hasObj?'📖':pct>=75?'🏆':pct>=60?'🎯':pct>=50?'✅':'💪';
    const color  = !hasObj?'var(--ink)':pct>=50?'var(--green)':'var(--red)';
    const msg    = !hasObj?'Study the model answers and marking schemes carefully.'
                 : pct>=75?"Outstanding! You're well prepared."
                 : pct>=60?"Good work — keep pushing, you're almost there."
                 : pct>=50?'You passed! More sessions will build confidence.'
                 :'Keep going — review the explanations and try again.';

    E.resultEmoji.textContent = emoji;
    E.resultScore.textContent = hasObj ? `${pct}%` : 'Theory';
    E.resultScore.style.color = color;
    E.resultGrade.textContent = grade;
    E.resultGrade.style.color = color;
    E.resultSummary.innerHTML =
      `<strong>${safe(r.student)}</strong> · ${safe(r.subject)} · ${safe(r.exam)}` +
      (r.timeout?' <span class="tag-timeout">Time elapsed</span>':'') +
      `<br><span class="res-msg">${msg}</span>`;

    const stats = [
      hasObj && {label:'Correct', val:r.correct, cls:'green'},
      hasObj && {label:'Wrong',   val:r.wrong,   cls:'red'},
      hasObj && {label:'Skipped', val:r.skipped, cls:''},
      r.thCount && {label:'Theory', val:r.thCount, cls:''},
      r.flags   && {label:'Flagged',val:r.flags,   cls:'amber'},
    ].filter(Boolean);

    E.resultStatsGrid.innerHTML = stats.map(s =>
      `<div class="rstat ${s.cls}"><strong>${s.val}</strong><span>${safe(s.label)}</span></div>`
    ).join('');

    if (hasObj) {
      E.resultBreakdown.style.display='block';
      E.resultBreakdown.innerHTML =
        `<div class="bk-bar"><div class="bk-fill" style="width:${pct}%;background:${color}"></div></div>` +
        `<div class="bk-lbl">${r.correct} correct · ${r.wrong} wrong · ${r.skipped} skipped</div>` +
        (r.flags?`<div class="bk-flag">🚩 ${r.flags} flagged for review</div>`:'');
    } else {
      E.resultBreakdown.style.display='none';
    }
  }

  /* ════════ REVIEW ════════ */
  function enterReview() {
    S.reviewMode=true; S.idx=0; S.showAnswer=true;
    buildPills(); renderQ(); showScreen('quiz');
  }

  /* ════════ EXIT ════════ */
  /* ════════ EXIT CONFIRMATION ════════ */
  function confirmExit() {
    if (!S.inSession || S.reviewMode) {
      // Not in active session — just go home
      if (S.timerId) { clearInterval(S.timerId); S.timerId = null; }
      S.inSession = false;
      showScreen('home');
      return;
    }
    showExitModal(
      S.mode === 'exam',
      () => {
        // Confirmed exit
        if (S.mode === 'exam') {
          finishSession(false);
        } else {
          if (S.timerId) { clearInterval(S.timerId); S.timerId = null; }
          S.inSession = false;
          showScreen('home');
        }
      }
    );
  }

  function showExitModal(isExam, onConfirm) {
    const modal = document.getElementById('exitConfirmModal');
    const icon  = document.getElementById('exitModalIcon');
    const title = document.getElementById('exitModalTitle');
    const sub   = document.getElementById('exitModalSub');
    const stay  = document.getElementById('exitModalStay');
    const leave = document.getElementById('exitModalLeave');
    if (!modal) { onConfirm(); return; }

    icon.textContent  = isExam ? '⚠️' : '🚪';
    title.textContent = isExam ? 'Exit Exam?' : 'Exit Session?';
    sub.textContent   = isExam
      ? 'Your answers will be submitted and scored.'
      : 'Your progress in this session will be lost.';
    leave.textContent = isExam ? 'Submit & Exit' : 'Exit';

    modal.classList.remove('hidden');

    // Clean up old listeners
    const newStay  = stay.cloneNode(true);
    const newLeave = leave.cloneNode(true);
    stay.parentNode.replaceChild(newStay, stay);
    leave.parentNode.replaceChild(newLeave, leave);

    document.getElementById('exitModalStay').addEventListener('click', () => {
      modal.classList.add('hidden');
    });
    document.getElementById('exitModalLeave').addEventListener('click', () => {
      modal.classList.add('hidden');
      onConfirm();
    });
  }

  function goHome() {
    if (S.timerId) { clearInterval(S.timerId); S.timerId=null; }
    S.inSession=false;
    showScreen('home');
  }

  /* ════════ HISTORY ════════ */
  function renderHistory() {
    const hist = getHistory();
    if (!S.currentUser) {
      E.historyList.innerHTML='<div class="empty-history">Login to see your history.</div>'; return;
    }
    if (!hist.length) {
      E.historyList.innerHTML='<div class="empty-history">No sessions yet — start your first practice!</div>'; return;
    }
    E.historyList.innerHTML = hist.slice(0,25).map(r => `
      <div class="hi-item">
        <div class="hi-main">
          <div class="hi-sub">${safe(r.subject)}</div>
          <div class="hi-meta">${safe(r.exam)} · ${safe(r.mode)} · ${safe(r.type||'objective')}</div>
          <div class="hi-date">${safe(r.date)}</div>
        </div>
        <div class="hi-right">
          <div class="hi-score ${r.pct==null?'':r.pct>=50?'pass':'fail'}">
            ${r.pct!=null?r.pct+'%':'—'}
          </div>
          ${r.pct!=null?`<div class="hi-fraction">${r.correct}/${r.total}</div>`:''}
        </div>
      </div>`
    ).join('');
  }

  function clearHistory() {
    if (!S.currentUser||!confirm('Clear all history for '+S.currentUser+'?')) return;
    if (S.users[S.currentUser]) S.users[S.currentUser].history=[];
    saveSafe(SK.users, S.users);
    renderHistory(); refreshStats();
  }

  function getHistory() { return S.users[S.currentUser]?.history||[]; }

  function refreshStats() {
    const hist = getHistory();
    const objH = hist.filter(r => r.pct!=null);
    E.hStatSessions.textContent = hist.length;
    E.hStatAvg.textContent  = objH.length ? Math.round(objH.reduce((s,r)=>s+r.pct,0)/objH.length)+'%' : '—';
    E.hStatBest.textContent = objH.length ? Math.max(...objH.map(r=>r.pct))+'%' : '—';
  }

  /* ════════ PAYWALL ════════ */
  function checkAccess() {
    const d = loadSafe(SK.access);
    return !!(d?.expires && new Date(d.expires) > new Date());
  }

  function getFreeUsed() {
    const d = loadSafe(SK.free);
    return d?.n || 0;
  }

  function getFreeSnaps() {
    const d = loadSafe(SK.free);
    return d?.snaps || 0;
  }

  function updateFreeTrialIndicator() {
    // Show a subtle indicator on home screen of remaining trial questions
    const remaining = Math.max(0, FREE_TRIAL_LIMIT - S.freeUsed);
    const pill = E.studentPill;
    if (pill && !S.hasAccess && S.currentUser) {
      const orig = pill.textContent;
      if (remaining <= 3 && remaining > 0) {
        pill.innerHTML = `${safe(S.currentUser)} &nbsp;·&nbsp; <span style="color:var(--amber);font-weight:600">${remaining} free question${remaining===1?'':'s'} left</span>`;
      } else if (remaining === 0) {
        pill.innerHTML = `${safe(S.currentUser)} &nbsp;·&nbsp; <span style="color:var(--red,#e55)">Free trial complete</span>`;
      }
    }
  }

  function showPaywall(reason) {
    if (E.paywallBadge) {
      E.paywallBadge.textContent = reason === 'trial' ? 'FREE TRIAL COMPLETE' : 'PREMIUM FEATURE';
    }
    // Show early adopter counter
    updateEarlyAdopterBanner();
    E.paywallOverlay.classList.remove('hidden');
  }

  function updateEarlyAdopterBanner() {
    // In production this would fetch from backend. For now simulate with localStorage count.
    const sold = loadSafe('mea-ea-sold') || 0;
    const remaining = Math.max(0, EARLY_ADOPTER_CAP - sold);
    if (E.earlyAdopterCounter) {
      if (remaining > 0) {
        E.earlyAdopterCounter.textContent = `${remaining} of 100 spots remaining`;
        if (E.earlyAdopterBanner) E.earlyAdopterBanner.style.display = '';
        if (E.payBtn) {
          E.payBtn.textContent = `Get Early Access — ₦2,000/quarter →`;
        }
      } else {
        // Early adopter cap reached — show standard price
        if (E.earlyAdopterBanner) E.earlyAdopterBanner.style.display = 'none';
        if (E.payBtn) E.payBtn.textContent = `Get Student Pass — ₦2,500/quarter →`;
      }
    }
  }

  function grantAccess(days, tier) {
    // Extend from current expiry if still active, not from today
    const existing = loadSafe(SK.access);
    const base = (existing?.expires && new Date(existing.expires) > new Date())
      ? new Date(existing.expires)   // active sub — extend from expiry
      : new Date();                  // no active sub — start from today
    const exp = new Date(base);
    exp.setDate(exp.getDate() + days);
    saveSafe(SK.access, { expires: exp.toISOString() });
    saveSafe(SK.tier, tier || 'student');
    S.hasAccess = true;
    S.tier = tier || 'student';
    E.paywallOverlay.classList.add('hidden');
    const extendedFrom = existing?.expires && new Date(existing.expires) > new Date()
      ? ` (extended from your current expiry)` : '';
    alert(`✅ Access granted until ${exp.toLocaleDateString('en-NG')}${extendedFrom}. Welcome to My Exams App.`);
  }

  // ⚙️ Same Vercel project as the snap-and-mark API — add a /api/verify-payment
  // serverless function there (see handoff notes) that calls Paystack's
  // /transaction/verify/:reference with your SECRET key and returns the
  // entitlement (tier + days) based on the amount actually paid.
  const API_BASE = 'https://editoby-api.vercel.app';

  // Grants access ONLY after the payment is confirmed server-side against
  // Paystack — the client-side Paystack callback firing is not sufficient
  // proof of payment on its own (it can be triggered without a real charge
  // via devtools), so we never call grantAccess() directly from a Paystack
  // callback anymore.
  async function verifyAndGrant(reference, fallbackTier, fallbackDays) {
    try {
      const res = await fetch(API_BASE + '/api/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reference })
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.verified) {
        // Trust the server's determination of tier/days (based on amount
        // actually paid), not whatever the client thinks it bought.
        grantAccess(data.days || fallbackDays, data.tier || fallbackTier);
        return true;
      }
      alert('We could not confirm this payment yet. If you were charged, please contact support with reference: ' + reference);
      return false;
    } catch (err) {
      alert('Could not verify payment (network error). If you were charged, please contact support with reference: ' + reference);
      return false;
    }
  }

  /* ════════ EMAIL MODAL (replaces native prompt() for payment email) ════════ */
  /* ════════ CONFIRM MODAL (replaces native browser confirm()) ════════ */
  function showConfirmModal(message, confirmLabel = 'Yes', cancelLabel = 'Cancel') {
    return new Promise((resolve) => {
      let overlay = document.getElementById('meaConfirmModalOverlay');
      if (overlay) overlay.remove();

      overlay = document.createElement('div');
      overlay.id = 'meaConfirmModalOverlay';
      overlay.style.cssText = `
        position:fixed; inset:0; background:rgba(5,10,20,.72);
        display:flex; align-items:center; justify-content:center;
        z-index:10000; padding:1rem; font-family:var(--sans,sans-serif);
      `;
      overlay.innerHTML = `
        <div style="background:#0a1628; border:1.5px solid var(--gold,#d4af37); border-radius:14px;
                    padding:1.75rem 1.5rem; max-width:340px; width:100%; box-shadow:0 10px 40px rgba(0,0,0,.5);">
          <p style="margin:0 0 1.1rem; color:#fff; font-size:.95rem; line-height:1.5;">${safe(message)}</p>
          <div style="display:flex; gap:.6rem;">
            <button id="meaConfirmCancel" style="flex:1; padding:.65rem; border-radius:9px; border:1.5px solid #26344a;
                    background:transparent; color:#fff; font-weight:600; font-size:.85rem;">${safe(cancelLabel)}</button>
            <button id="meaConfirmOk" style="flex:1; padding:.65rem; border-radius:9px; border:none;
                    background:var(--gold,#d4af37); color:#0a1628; font-weight:700; font-size:.85rem;">${safe(confirmLabel)}</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);

      const cleanup = (val) => { overlay.remove(); resolve(val); };
      document.getElementById('meaConfirmCancel').addEventListener('click', () => cleanup(false));
      document.getElementById('meaConfirmOk').addEventListener('click', () => cleanup(true));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) cleanup(false); });
    });
  }

  function getEmailViaModal() {
    return new Promise((resolve) => {
      let overlay = document.getElementById('emailModalOverlay');
      if (overlay) overlay.remove(); // fresh each time, avoids stale listeners

      overlay = document.createElement('div');
      overlay.id = 'emailModalOverlay';
      overlay.style.cssText = `
        position:fixed; inset:0; background:rgba(5,10,20,.72);
        display:flex; align-items:center; justify-content:center;
        z-index:10000; padding:1rem; font-family:var(--sans,sans-serif);
        animation:toastSlideUp .2s ease;
      `;
      overlay.innerHTML = `
        <div style="background:#0a1628; border:1.5px solid var(--gold,#d4af37); border-radius:14px;
                    padding:1.75rem 1.5rem; max-width:340px; width:100%; box-shadow:0 10px 40px rgba(0,0,0,.5);">
          <h3 style="margin:0 0 .5rem; color:#fff; font-size:1.05rem; font-weight:700;">Enter your email</h3>
          <p style="margin:0 0 1rem; color:var(--text-dim,#9aa5b1); font-size:.85rem; line-height:1.4;">
            We'll send your payment receipt here.
          </p>
          <input id="emailModalInput" type="email" inputmode="email" autocomplete="email" placeholder="you@example.com"
                 style="width:100%; box-sizing:border-box; padding:.7rem .85rem; border-radius:9px;
                        border:1.5px solid #26344a; background:#0d1b2a; color:#fff; font-size:.95rem; outline:none;" />
          <p id="emailModalError" style="display:none; color:var(--red,#e55); font-size:.78rem; margin:.4rem 0 0;">
            Please enter a valid email address.
          </p>
          <div style="display:flex; gap:.6rem; margin-top:1.1rem;">
            <button id="emailModalCancel" style="flex:1; padding:.65rem; border-radius:9px; border:1.5px solid #26344a;
                    background:transparent; color:#fff; font-weight:600; font-size:.85rem;">Cancel</button>
            <button id="emailModalContinue" style="flex:1; padding:.65rem; border-radius:9px; border:none;
                    background:var(--gold,#d4af37); color:#0a1628; font-weight:700; font-size:.85rem;">Continue</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);

      const input   = document.getElementById('emailModalInput');
      const errEl   = document.getElementById('emailModalError');
      const cleanup = (val) => { overlay.remove(); resolve(val); };

      input.focus();
      document.getElementById('emailModalCancel').addEventListener('click', () => cleanup(null));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) cleanup(null); });
      const submit = () => {
        const val = (input.value || '').trim();
        if (!val.includes('@') || !val.includes('.')) { errEl.style.display = 'block'; return; }
        cleanup(val);
      };
      document.getElementById('emailModalContinue').addEventListener('click', submit);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
    });
  }

  async function upgradeToPlus(mode) {
    // mode: 'upgrade' = pay difference ₦1,000, keep expiry
    //       'renew'   = pay full ₦3,500, extend from current expiry
    const email = await getEmailViaModal();
    if (!email) return; // cancelled

    const PAYSTACK_KEY = 'pk_live_5d12ee2a90900116dc222107e059a06214c085ff';

    if (mode === 'upgrade') {
      // Pay ₦1,000 difference — keep existing expiry, just upgrade tier
      const handler = window.PaystackPop.setup({
        key: PAYSTACK_KEY, email,
        amount: 100000, // ₦1,000 in kobo
        currency: 'NGN',
        ref: 'MEA-UPGRADE-' + Date.now(),
        metadata: { custom_fields: [
          { display_name: 'Plan', variable_name: 'plan', value: 'Upgrade to Student Pass Plus (₦1,000)' },
        ]},
        onClose() {},
        callback(response) {
          (async () => {
            const res = await fetch(API_BASE + '/api/verify-payment', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ reference: response.reference })
            }).catch(() => null);
            const data = res ? await res.json().catch(() => ({})) : {};
            if (!res || !res.ok || !data.verified) {
              alert('We could not confirm this payment yet. If you were charged, please contact support with reference: ' + response.reference);
              return;
            }
            // Keep existing expiry, just change tier
            saveSafe(SK.tier, 'plus');
            S.tier = 'plus';
            E.paywallOverlay?.classList.add('hidden');
            alert('✅ Upgraded to Student Pass Plus! Teach Me are now unlocked for your current subscription period.');
            renderQ(); // re-render to show AI buttons
          })();
        }
      });
      handler.openIframe();
    } else {
      // Renew as Plus — full ₦3,500, extends from current expiry
      handlePayment('plus', 'quarterly');
    }
  }

  async function handlePayment(tier, period) {
    tier   = tier   || 'student';
    period = period || 'quarterly';

    const sold          = loadSafe('mea-ea-sold') || 0;
    const isEarlyAdopter = sold < EARLY_ADOPTER_CAP;

    // Amount map in kobo
    const amounts = {
      'student-quarterly': isEarlyAdopter ? EARLY_ADOPTER_PRICE : STANDARD_PRICE,
      'student-yearly':    750000,
      'plus-quarterly':    350000,
      'plus-yearly':       1050000,
      'jamb-quarterly':    150000,
    };

    const labels = {
      'student-quarterly': isEarlyAdopter ? 'Student Pass — Early Access (₦2,000/quarter)' : 'Student Pass (₦2,500/quarter)',
      'student-yearly':    'Student Pass — Full Year (₦7,500)',
      'plus-quarterly':    'Student Pass Plus (₦3,500/quarter)',
      'plus-yearly':       'Student Pass Plus — Full Year (₦10,500)',
      'jamb-quarterly':    'JAMB Only (₦1,500/quarter)',
    };

    // Days of access granted
    const days = {
      'student-quarterly': 90,
      'student-yearly':    365,
      'plus-quarterly':    90,
      'plus-yearly':       365,
      'jamb-quarterly':    90,
    };

    const key    = tier + '-' + period;
    const amount = amounts[key];
    const label  = labels[key];
    const daysToGrant = days[key];

    if (!amount) return;

    const email = await getEmailViaModal();
    if (!email) return; // cancelled

    const PAYSTACK_KEY = 'pk_live_5d12ee2a90900116dc222107e059a06214c085ff';
    // 🔑 When Paystack approves your account, replace the line above with:
    // const PAYSTACK_KEY = 'pk_live_YOUR_LIVE_KEY_HERE';

    const handler = window.PaystackPop.setup({
      key: PAYSTACK_KEY,
      email,
      amount,
      currency: 'NGN',
      ref: 'MEA-' + tier.toUpperCase() + '-' + Date.now(),
      metadata: {
        custom_fields: [
          { display_name: 'Plan',   variable_name: 'plan',   value: label },
          { display_name: 'App',    variable_name: 'app',    value: 'My Exams App' },
          { display_name: 'Period', variable_name: 'period', value: period },
        ]
      },
      onClose() {},
      callback(response) {
        // Paystack's SDK rejects an `async` function here during its own
        // internal validation (it wants a plain function reference), so we
        // keep this synchronous and run the actual async verification inside.
        (async () => {
          const verified = await verifyAndGrant(response.reference, tier, daysToGrant);
          if (verified && (tier === 'student' || tier === 'jamb') && isEarlyAdopter && period === 'quarterly') {
            saveSafe('mea-ea-sold', sold + 1);
          }
        })();
      }
    });
    handler.openIframe();
  }

  function handleSchoolEnquiry() {
    const email = 'schools@myexamsapp.com';
    const subject = encodeURIComponent('School Bundle Enquiry — My Exams App');
    const body    = encodeURIComponent(
      'Hello,\n\nI am interested in a school bundle for My Exams App.\n\n' +
      'School name:\nNumber of students:\nPreferred tier (Standard / Branded / Premium):\nContact number:\n\nThank you.'
    );
    window.open(`mailto:${email}?subject=${subject}&body=${body}`);
  }

  /* ════════════════════════════════
     COMMUNITY QUIZ
  ════════════════════════════════ */
  const SUBJECT_KEYS = Object.keys(EXAM_BANK);
  const QC_STORE = 'mea-challenges-v1';
  let _pendingChallenge = null;
  let _waitingRoomTimer = null;
  let _waitingRoomCountdownTicker = null;
  let _isWaitingRoomCreator = false;
  const WAITING_ROOM_TIMEOUT_MS = 2 * 60 * 1000;
  const MAX_PENDING_CHALLENGES = 5;

  function initCommunityQuiz() {
    const btn = document.getElementById('quizChallengeBtn');
    const modal = document.getElementById('quizChallengeModal');
    if (!btn || !modal) return;

    // Show trigger button only for paid users
    if (S.hasAccess) btn.classList.remove('hidden');

    btn.addEventListener('click', openQuizChallenge);
    document.getElementById('qcClose').addEventListener('click', closeQuizChallenge);
    modal.addEventListener('click', e => { if (e.target === modal) closeQuizChallenge(); });

    document.getElementById('qcCreateBtn').addEventListener('click', () => showQcPanel('qcCreate'));
    document.getElementById('qcBackBtn').addEventListener('click',   () => showQcPanel('qcHome'));
    document.getElementById('qcShareBackBtn')?.addEventListener('click', () => { showQcPanel('qcHome'); renderPendingChallenges(); });
    document.getElementById('qcWaitingBackBtn')?.addEventListener('click', () => {
      clearInterval(_waitingRoomTimer);
      clearInterval(_waitingRoomCountdownTicker);
      showQcPanel('qcHome');
      renderPendingChallenges();
      refreshChallengeBadgeState();
    });
    document.getElementById('qcJoinBtn').addEventListener('click',   () => {
      document.getElementById('qcJoinRow').classList.toggle('hidden');
    });
    document.getElementById('qcJoinConfirm').addEventListener('click', joinChallenge);
    document.getElementById('qcGenerateBtn').addEventListener('click', generateChallenge);
    document.getElementById('qcShareLinkBtn').addEventListener('click', shareChallengeLink);
    document.getElementById('qcStartOwnBtn').addEventListener('click', startOwnAttempt);
    document.getElementById('qcNewChallengeBtn').addEventListener('click', () => showQcPanel('qcCreate'));
    document.getElementById('qcDoneBtn').addEventListener('click', closeQuizChallenge);
    document.getElementById('qcReadyBtn')?.addEventListener('click', markReady);
    document.getElementById('qcForceStartBtn')?.addEventListener('click', forceStartChallenge);
    document.getElementById('qcEndChallengeBtn')?.addEventListener('click', endChallengeFromWaitingRoom);
    document.querySelectorAll('input[name="qcSyncMode"]').forEach(radio => {
      radio.addEventListener('change', () => {
        document.getElementById('qcScheduledTimeWrap')?.classList.toggle('hidden', radio.value !== 'scheduled' || !radio.checked);
      });
    });

    // Populate subject checkboxes (multi-select)
    const subjectsWrap = document.getElementById('qcSubjects');
    if (subjectsWrap) SUBJECT_KEYS.forEach(s => {
      const label = document.createElement('label');
      label.className = 'qc-subject-check';
      label.innerHTML = `<input type="checkbox" value="${s}"/> <span>${safe(SUBJECTS[s]?.name || s)}</span>`;
      const input = label.querySelector('input');
      input.addEventListener('change', () => label.classList.toggle('checked', input.checked));
      subjectsWrap.appendChild(label);
    });

    // Check if arriving via challenge link
    const params = new URLSearchParams(window.location.search);
    const challengeCode = params.get('challenge');
    if (challengeCode) {
      history.replaceState(null, '', window.location.pathname);
      openQuizChallenge();
      document.getElementById('qcJoinCode').value = challengeCode;
      joinChallenge();
    }
  }

  function refreshChallengeBadgeState() {
    const all = loadSafe(QC_STORE, {});
    const needsAttention = Object.values(all).some(c => {
      if (c.ended) return false;
      if (!c.syncMode || c.syncMode === 'anytime') return false; // no "started" moment to alert about
      const completed = c.scores && c.scores[S.currentUser];
      return c.startedAt && !completed;
    });
    setChallengeBadge(needsAttention);
  }

  const _qcPanelOrder = ['qcHome','qcCreate','qcShare','qcLeaderboard','qcWaitingRoom'];
  let _qcCurrentPanel = 'qcHome';
  let _qcModalPanelHistory = [];

  function openQuizChallenge() {
    if (!S.hasAccess) { showPaywall('upgrade'); return; }
    if (!S.currentUser) { alert('Please log in first to use Community Quiz.'); return; }
    _qcModalPanelHistory = [];
    showQcPanel('qcHome');
    document.getElementById('quizChallengeModal').classList.remove('hidden');
    // Push a hash entry so the hardware/gesture back button can be caught
    // and used to navigate panels within the modal.
    history.pushState(null, '', window.location.pathname + '#mea-challenge');
    renderPendingChallenges();
    checkForStartedChallenges().then(() => { renderPendingChallenges(); refreshChallengeBadgeState(); });
  }

  function closeQuizChallenge() {
    clearInterval(_waitingRoomTimer);
    clearInterval(_waitingRoomCountdownTicker);
    document.getElementById('quizChallengeModal').classList.add('hidden');
    _qcModalPanelHistory = [];
    if (window.location.hash === '#mea-challenge') history.replaceState(null, '', window.location.pathname);
  }

  function showQcPanel(id, fromBack = false) {
    if (!fromBack && id !== _qcCurrentPanel) {
      if (id === 'qcHome') {
        _qcModalPanelHistory = []; // Home is the root — nothing further back
      } else {
        _qcModalPanelHistory.push(_qcCurrentPanel);
      }
    }
    _qcCurrentPanel = id;
    _qcPanelOrder.forEach(p => {
      const el = document.getElementById(p);
      if (el) el.classList.toggle('hidden', p !== id);
    });
  }

  // Instead of yanking the student straight into the quiz the moment a
  // scheduled/ready challenge starts (jarring if they're doing something
  // else), show a small dismissible notice with the choice to join now or
  // later. "Later" leaves a badge on the Challenge button as a reminder.
  function showChallengeStartedNotice(code, challenge, startedAt) {
    let card = document.getElementById('meaStartedNotice');
    if (card) card.remove();
    playChallengeBeep();

    card = document.createElement('div');
    card.id = 'meaStartedNotice';
    card.style.cssText = `
      position:fixed; bottom:1.25rem; left:50%; transform:translateX(-50%);
      background:#0a1628; border:1.5px solid var(--gold,#d4af37); border-radius:14px;
      padding:1.1rem 1.25rem; max-width:340px; width:calc(100% - 2rem);
      box-shadow:0 10px 40px rgba(0,0,0,.5); z-index:10001; font-family:var(--sans,sans-serif);
      text-align:center;
    `;
    card.innerHTML = `
      <button id="meaStartedClose" style="position:absolute; top:.6rem; right:.7rem; background:none; border:none;
              color:rgba(255,255,255,.5); font-size:1.1rem; cursor:pointer; line-height:1;">✕</button>
      <p style="margin:0 0 .7rem; color:#fff; font-size:.9rem; font-weight:600;">🎉 Your challenge has started!</p>
      <button id="meaStartedNow" style="width:100%; padding:.65rem; border-radius:9px; border:none; margin-bottom:.6rem;
              background:var(--gold,#d4af37); color:#0a1628; font-weight:700; font-size:.85rem;">Join Now</button>
      <p style="margin:0 0 .4rem; color:rgba(255,255,255,.5); font-size:.72rem;">Or remind me again in:</p>
      <div style="display:flex; gap:.4rem; margin-bottom:.6rem;">
        <button class="mea-snooze-opt" data-min="5" style="flex:1; padding:.5rem; border-radius:8px; border:1px solid #26344a; background:transparent; color:#fff; font-size:.75rem;">5 min</button>
        <button class="mea-snooze-opt" data-min="15" style="flex:1; padding:.5rem; border-radius:8px; border:1px solid #26344a; background:transparent; color:#fff; font-size:.75rem;">15 min</button>
        <button class="mea-snooze-opt" data-min="30" style="flex:1; padding:.5rem; border-radius:8px; border:1px solid #26344a; background:transparent; color:#fff; font-size:.75rem;">30 min</button>
      </div>
      <button id="meaStartedDecline" style="width:100%; padding:.4rem; border-radius:8px; border:none;
              background:transparent; color:rgba(255,255,255,.4); font-size:.72rem; text-decoration:underline; cursor:pointer;">Decline — I won't be joining this one</button>
    `;
    document.body.appendChild(card);

    document.getElementById('meaStartedClose').addEventListener('click', () => {
      card.remove();
      const challenges = loadSafe(QC_STORE, {});
      if (challenges[code]) { challenges[code].startedAt = startedAt; saveSafe(QC_STORE, challenges); }
      setChallengeBadge(true);
    });
    document.getElementById('meaStartedDecline').addEventListener('click', async () => {
      card.remove();
      try {
        await fetch(API_BASE + '/api/challenge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'remove_participant', code, student: S.currentUser }),
        });
      } catch (err) { /* still remove locally even if this fails */ }
      const challenges = loadSafe(QC_STORE, {});
      delete challenges[code];
      saveSafe(QC_STORE, challenges);
      refreshChallengeBadgeState();
      renderPendingChallenges();
    });
    document.getElementById('meaStartedNow').addEventListener('click', () => {
      card.remove();
      document.getElementById('quizChallengeModal')?.classList.add('hidden');
      startChallengeAttempt(challenge, startedAt);
    });
    card.querySelectorAll('.mea-snooze-opt').forEach(btn => {
      btn.addEventListener('click', () => {
        const minutes = parseInt(btn.dataset.min, 10);
        card.remove();
        const challenges = loadSafe(QC_STORE, {});
        if (challenges[code]) { challenges[code].startedAt = startedAt; saveSafe(QC_STORE, challenges); }
        setChallengeBadge(true);
        // Re-show the notice after the snooze period, unless the student
        // has since joined or the challenge ended in the meantime.
        setTimeout(() => {
          const latest = loadSafe(QC_STORE, {})[code];
          if (latest && !latest.ended && !(latest.scores && latest.scores[S.currentUser])) {
            showChallengeStartedNotice(code, challenge, startedAt);
          }
        }, minutes * 60000);
      });
    });
  }

  function playChallengeBeep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'sine'; osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.start(); osc.stop(ctx.currentTime + 0.35);
    } catch (err) { /* audio not available — badge/card still show visually */ }
  }

  function setChallengeBadge(show) {
    document.getElementById('qcChallengeBadge')?.classList.toggle('hidden', !show);
  }

  // Checked on login and whenever the Challenge modal opens — quietly (no
  // interrupting popup) flags the button if something the student owns or
  // joined has started without them actively watching for it.
  // Shows a one-time-per-day reminder toast for a scheduled challenge
  // that's coming up within the next 2 days.
  const MEA_REMINDED_STORE = 'mea-challenge-reminded-v1';
  function checkScheduledChallengeReminders() {
    if (!S.currentUser) return;
    const all = loadSafe(QC_STORE, {});
    const reminded = loadSafe(MEA_REMINDED_STORE, {});
    const todayKey = new Date().toDateString();
    const mine = Object.values(all).filter(c =>
      c.creator === S.currentUser && c.syncMode === 'scheduled'
      && c.scheduledStartAt && !c.startedAt && !c.ended
    );
    for (const c of mine) {
      if (reminded[c.code] === todayKey) continue;
      const daysUntil = Math.ceil((c.scheduledStartAt - Date.now()) / 86400000);
      if (daysUntil < 0 || daysUntil > 2) continue;
      const when = daysUntil === 0 ? 'today' : daysUntil === 1 ? 'in 1 day' : 'in 2 days';
      showInfoToast(`📅 You have a scheduled challenge (${c.code}) starting ${when}.`);
      reminded[c.code] = todayKey;
      saveSafe(MEA_REMINDED_STORE, reminded);
      break;
    }
  }

  async function checkForStartedChallenges() {
    if (!S.currentUser) return;
    const inQuiz = document.getElementById('quizScreen')?.classList.contains('active');

    const all = loadSafe(QC_STORE, {});
    const candidates = Object.values(all).filter(c =>
      c.syncMode && c.syncMode !== 'anytime' && !c.ended && !c.startedAt
      && (c.creator === S.currentUser || c.joinedAsParticipant)
    );
    if (!candidates.length) return;

    const justStarted = [];
    for (const c of candidates) {
      try {
        const res = await fetch(API_BASE + '/api/challenge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'status', code: c.code }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok && data.startedAt) {
          all[c.code].startedAt = data.startedAt;
          justStarted.push({ code: c.code, challenge: all[c.code], startedAt: data.startedAt });
        }
      } catch (err) { /* skip — try again next time */ }
    }
    if (!justStarted.length) return;

    saveSafe(QC_STORE, all);
    setChallengeBadge(true);
    playChallengeBeep();

    if (inQuiz) return; // badge is set — they'll see it once they finish

    if (justStarted.length === 1) {
      showChallengeStartedNotice(justStarted[0].code, justStarted[0].challenge, justStarted[0].startedAt);
    } else {
      showMultipleChallengesStartedNotice(justStarted);
    }
  }

  function showMultipleChallengesStartedNotice(startedList) {
    let card = document.getElementById('meaStartedNotice');
    if (card) card.remove();
    playChallengeBeep();

    card = document.createElement('div');
    card.id = 'meaStartedNotice';
    card.style.cssText = `
      position:fixed; bottom:1.25rem; left:50%; transform:translateX(-50%);
      background:#0a1628; border:1.5px solid var(--gold,#d4af37); border-radius:14px;
      padding:1.1rem 1.25rem; max-width:340px; width:calc(100% - 2rem);
      box-shadow:0 10px 40px rgba(0,0,0,.5); z-index:10001; font-family:var(--sans,sans-serif);
      text-align:center;
    `;
    const rows = startedList.map(({code, challenge}) => {
      const endTxt = challenge.time > 0
        ? ' · ends ' + new Date(challenge.startedAt + challenge.time * 60000).toLocaleTimeString(undefined, { hour:'numeric', minute:'2-digit' })
        : '';
      return `
        <div class="qc-pending-row" style="text-align:left; margin-bottom:.5rem;">
          <div class="qc-pending-info">
            <div class="qc-pending-code">${safe(code)}</div>
            <div class="qc-pending-sub">${safe(challenge.subject||'')}${endTxt}</div>
          </div>
          <button class="qc-pending-btn" data-code="${safe(code)}">Join</button>
        </div>
      `;
    }).join('');
    card.innerHTML = `
      <button id="meaStartedClose" style="position:absolute; top:.6rem; right:.7rem; background:none; border:none;
              color:rgba(255,255,255,.5); font-size:1.1rem; cursor:pointer; line-height:1;">✕</button>
      <p style="margin:0 0 .7rem; color:#fff; font-size:.9rem; font-weight:600;">🎉 ${startedList.length} challenges have started!</p>
      <p style="margin:0 0 .7rem; color:rgba(255,255,255,.55); font-size:.75rem;">Pick one to join now — the rest stay in your challenge list.</p>
      ${rows}
    `;
    document.body.appendChild(card);

    document.getElementById('meaStartedClose').addEventListener('click', () => card.remove());
    card.querySelectorAll('.qc-pending-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const code = btn.dataset.code;
        const picked = startedList.find(s => s.code === code);
        card.remove();
        if (picked) startChallengeAttempt(picked.challenge, picked.startedAt);
      });
    });
  }

  function generateChallengeCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'MEA-';
    for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
  }

  function getMyChallenges() {
    const all = loadSafe(QC_STORE, {});
    return Object.values(all)
      .filter(c => c.creator === S.currentUser)
      .sort((a, b) => (b.createdAt||0) - (a.createdAt||0));
  }

  function getJoinedChallenges() {
    const all = loadSafe(QC_STORE, {});
    return Object.values(all)
      .filter(c => c.joinedAsParticipant && c.creator !== S.currentUser)
      .sort((a, b) => (b.createdAt||0) - (a.createdAt||0));
  }

  function renderPendingChallenges() {
    const wrap = document.getElementById('qcPendingWrap');
    const list = document.getElementById('qcPendingList');
    const countEl = document.getElementById('qcPendingCount');
    if (!wrap || !list) return;

    const mine   = getMyChallenges().slice(0, MAX_PENDING_CHALLENGES);
    const joined = getJoinedChallenges().slice(0, MAX_PENDING_CHALLENGES);
    countEl && (countEl.textContent = mine.length);
    const maxEl = document.getElementById('qcPendingMax');
    if (maxEl) maxEl.textContent = MAX_PENDING_CHALLENGES;
    wrap.classList.toggle('hidden', mine.length === 0 && joined.length === 0);

    const renderRow = (c, isOwner) => {
      const completed = !!(c.scores && c.scores[S.currentUser]);
      const isDone = c.ended || completed;
      let statusLabel;
      if (c.ended)      statusLabel = '⏹ Ended';
      else if (completed) statusLabel = '✅ Completed';
      else if (c.syncMode === 'scheduled' && !c.startedAt) {
        const when = c.scheduledStartAt
          ? new Date(c.scheduledStartAt).toLocaleString(undefined, { month:'short', day:'numeric', hour:'numeric', minute:'2-digit' })
          : '';
        statusLabel = '📅 Scheduled' + (when ? ' for ' + when : '');
      }
      else if (c.syncMode === 'ready' && !c.startedAt)     statusLabel = '⏱ Waiting room';
      else if (c.startedAt && c.syncMode && c.syncMode !== 'anytime') {
        const endTxt = c.time > 0
          ? ' · ends ' + new Date(c.startedAt + c.time * 60000).toLocaleTimeString(undefined, { hour:'numeric', minute:'2-digit' })
          : '';
        statusLabel = '▶ Ongoing' + endTxt;
      } else statusLabel = '▶ Not yet taken';

      const actionBtn = isDone
        ? `<button class="qc-pending-btn" data-code="${safe(c.code)}" data-action="results">View Results</button>`
        : `<button class="qc-pending-btn" data-code="${safe(c.code)}" data-action="continue">Continue</button>`;
      const deleteBtn = isOwner
        ? `<button class="qc-pending-delete" data-code="${safe(c.code)}" data-action="delete">Delete</button>`
        : '';

      return `
        <div class="qc-pending-row">
          <div class="qc-pending-info">
            <div class="qc-pending-code">${safe(c.code)}${isOwner ? '' : ' <span class="qc-pending-tag">Joined</span>'}</div>
            <div class="qc-pending-sub">${safe(c.subject||'')} · ${statusLabel}</div>
          </div>
          ${actionBtn}
          ${deleteBtn}
        </div>
      `;
    };

    list.innerHTML = mine.map(c => renderRow(c, true)).join('')
      + joined.map(c => renderRow(c, false)).join('');

    list.querySelectorAll('[data-action="continue"]').forEach(btn => {
      btn.addEventListener('click', () => continueChallenge(btn.dataset.code));
    });
    list.querySelectorAll('[data-action="results"]').forEach(btn => {
      btn.addEventListener('click', () => viewChallengeResults(btn.dataset.code));
    });
    list.querySelectorAll('[data-action="delete"]').forEach(btn => {
      btn.addEventListener('click', () => deleteChallenge(btn.dataset.code));
    });
  }

  async function viewChallengeResults(code) {
    const local = loadSafe(QC_STORE, {})[code];
    if (local && local.scores) showChallengeLeaderboard(code, local.scores);
    try {
      const res = await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'leaderboard', code }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) showChallengeLeaderboard(code, data.scores);
    } catch (err) { /* local scores already shown as a fallback */ }
  }

  function continueChallenge(code) {
    const challenges = loadSafe(QC_STORE, {});
    const challenge = challenges[code];
    if (!challenge) return;
    window._currentChallengeCode = code;
    const isOwner = challenge.creator === S.currentUser;
    if (challenge.syncMode && challenge.syncMode !== 'anytime' && !challenge.startedAt) {
      _pendingChallenge = challenge;
      openWaitingRoom(code, isOwner);
    } else if (challenge.syncMode && challenge.syncMode !== 'anytime' && challenge.startedAt) {
      showChallengeStartedNotice(code, challenge, challenge.startedAt);
    } else {
      document.getElementById('qcCodeDisplay').textContent = code;
      showQcPanel('qcShare');
    }
  }

  async function deleteChallenge(code, silent = false) {
    if (!silent) {
      const ok = await showConfirmModal(`Delete challenge ${code}? Anyone with the code will no longer be able to join.`, 'Delete', 'Cancel');
      if (!ok) return;
    }
    try {
      await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'end_challenge', code }),
      });
    } catch (err) { /* still remove locally even if the network call fails */ }
    const challenges = loadSafe(QC_STORE, {});
    if (challenges[code]) { challenges[code].ended = true; saveSafe(QC_STORE, challenges); }
    renderPendingChallenges();
    refreshChallengeBadgeState();
  }

  const RECENT_QS_STORE = 'mea-challenge-recent-qs-v1';
  const RECENT_QS_CAP = 80; // roughly several challenges' worth of history

  // Picks `count` questions from `pool`, preferring ones this student hasn't
  // used in their recent challenges — so repeated challenges with the same
  // friends don't keep surfacing the same questions. Falls back to allowing
  // repeats (oldest-used first) only if the pool genuinely isn't big enough
  // to avoid it.
  function pickChallengeQuestions(pool, count) {
    if (!pool.length) return [];
    const recentIds = loadSafe(RECENT_QS_STORE, []);
    const recentSet = new Set(recentIds);
    const fresh = shuffle(pool.filter(q => q.id && !recentSet.has(q.id)));
    const stale = pool.filter(q => q.id && recentSet.has(q.id))
      .sort((a, b) => recentIds.indexOf(a.id) - recentIds.indexOf(b.id)); // oldest-used first

    const selected = fresh.slice(0, count);
    if (selected.length < count) {
      selected.push(...stale.slice(0, count - selected.length));
    }

    // Remember these as recently used (most-recent at the end), capped.
    const usedIds = selected.map(q => q.id).filter(Boolean);
    const updated = [...recentIds.filter(id => !usedIds.includes(id)), ...usedIds].slice(-RECENT_QS_CAP);
    saveSafe(RECENT_QS_STORE, updated);

    return selected;
  }

  async function generateChallenge() {
    // Keep at most MAX_PENDING_CHALLENGES total — auto-retire the oldest
    // one rather than blocking creation. Since we're building this on a
    // free-tier backend, there's no real reason to make someone manually
    // clean up before they can make a new challenge.
    const mine = getMyChallenges();
    if (mine.length >= MAX_PENDING_CHALLENGES) {
      const oldest = mine[mine.length - 1];
      await deleteChallenge(oldest.code, true); // silent — no confirm prompt for auto-eviction
    }

    const subjectBoxes = [...document.querySelectorAll('#qcSubjects input:checked')].map(i => i.value);
    if (!subjectBoxes.length) { showInfoToast('Pick at least one subject.'); return; }
    const examBoard = document.getElementById('qcExamBoard')?.value || '';
    const yearRange = document.getElementById('qcYearRange')?.value || '';
    const count   = parseInt(document.getElementById('qcCount').value);
    const time    = parseInt(document.getElementById('qcTime').value);
    const syncMode = document.querySelector('input[name="qcSyncMode"]:checked')?.value || 'anytime';
    let scheduledStartAt = null;
    if (syncMode === 'scheduled') {
      const raw = document.getElementById('qcScheduledTime')?.value;
      if (!raw) { showInfoToast('Pick a date and time for the challenge to start.'); return; }
      scheduledStartAt = new Date(raw).getTime();
      if (!Number.isFinite(scheduledStartAt) || scheduledStartAt <= Date.now()) {
        showInfoToast('Pick a start time in the future.');
        return;
      }
    }

    // Split the requested count evenly across subjects, but keep each
    // subject's questions grouped together (not interleaved) so students
    // can switch between subjects the same way they do in a normal exam.
    const perSubject = Math.max(1, Math.floor(count / subjectBoxes.length));
    let pool = [];
    const subjectRanges = {};
    let offset = 0;
    for (const subject of subjectBoxes) {
      const bank = EXAM_BANK[subject];
      if (!bank) continue;
      let sourcePool = bank.objective || [];
      if (examBoard) sourcePool = sourcePool.filter(q => q.exam === examBoard);
      if (yearRange) {
        const [from, to] = yearRange.split('-').map(Number);
        sourcePool = sourcePool.filter(q => q.year >= from && q.year <= to);
      }
      const picked = pickChallengeQuestions(sourcePool, perSubject).map(q => ({ ...q, sourceSubject: subject }));
      if (!picked.length) continue;
      subjectRanges[subject] = { start: offset, end: offset + picked.length - 1 };
      offset += picked.length;
      pool = pool.concat(picked);
    }
    if (!pool.length) { showInfoToast('Not enough questions match those filters — try widening the exam board or year range.'); return; }

    const subjectLabel = subjectBoxes.map(s => SUBJECTS[s]?.name || s).join(' + ');
    const code = generateChallengeCode();
    const genBtn = document.getElementById('qcGenerateBtn');
    if (genBtn) { genBtn.disabled = true; genBtn.textContent = 'Creating…'; }

    try {
      const res = await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create', code, subject: subjectLabel, subjects: subjectBoxes, subjectRanges,
          count: pool.length, time, questions: pool, creator: S.currentUser, syncMode, scheduledStartAt,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) throw new Error(data.error || 'Could not create challenge');

      // Also keep a local copy so the creator's own attempt works instantly.
      const challenges = loadSafe(QC_STORE, {});
      const challengeObj = {
        code, subject: subjectLabel, subjects: subjectBoxes, subjectRanges, count: pool.length, time,
        questions: pool.map(q => q.id || pool.indexOf(q)),
        questionData: pool,
        expires: Date.now() + 24 * 60 * 60 * 1000,
        creator: S.currentUser,
        syncMode, scheduledStartAt,
        startedAt: syncMode === 'anytime' ? Date.now() : null,
        createdAt: Date.now(), ended: false,
        scores: {},
      };
      challenges[code] = challengeObj;
      saveSafe(QC_STORE, challenges);

      document.getElementById('qcCodeDisplay').textContent = code;
      window._currentChallengeCode = code;

      if (syncMode !== 'anytime') {
        _pendingChallenge = challengeObj;
        openWaitingRoom(code, true);
      } else {
        showQcPanel('qcShare');
      }
    } catch (err) {
      showInfoToast('Could not create challenge — check your connection and try again.');
    } finally {
      if (genBtn) { genBtn.disabled = false; genBtn.textContent = 'Generate Code →'; }
    }
  }

  function shareChallengeLink() {
    const code = window._currentChallengeCode;
    if (!code) return;
    const url  = window.location.origin + window.location.pathname + '?challenge=' + code;
    const subj = loadSafe(QC_STORE, {})[code]?.subject || '';
    const text = `🏆 I challenge you! Take this ${subj} quiz on My Exams App.\n\nCode: ${code}\nLink: ${url}`;
    if (navigator.share) {
      navigator.share({ title: 'My Exams App Challenge', text, url }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(text).then(() => alert('Challenge link copied!')).catch(() => alert('Link: ' + url));
    }
  }

  async function joinChallenge() {
    const code = (document.getElementById('qcJoinCode').value || '').trim().toUpperCase();
    if (!code) return;

    const joinBtn = document.getElementById('qcJoinConfirm');
    if (joinBtn) { joinBtn.disabled = true; joinBtn.textContent = 'Joining…'; }

    try {
      // Local first (covers the creator's own device instantly), then the
      // shared backend for anyone joining from a different device.
      const local = loadSafe(QC_STORE, {})[code];
      if (local) {
        if (local.ended) { showInfoToast('This challenge has ended.'); return; }
        if (Date.now() > local.expires) { showInfoToast('This challenge has expired (challenges last 24 hours).'); return; }
        window._currentChallengeCode = code;
        if (local.syncMode && local.syncMode !== 'anytime' && !local.startedAt) {
          _pendingChallenge = local;
          openWaitingRoom(code, local.creator === S.currentUser);
        } else if (local.syncMode && local.syncMode !== 'anytime' && local.startedAt) {
          showChallengeStartedNotice(code, local, local.startedAt);
        } else {
          startChallengeAttempt(local);
        }
        return;
      }

      const res = await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'join', code, student: S.currentUser }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        if (res.status === 409 && data.alreadyCompleted) {
          showInfoToast("You've already completed this challenge — check the leaderboard for your result.");
          const lbRes = await fetch(API_BASE + '/api/challenge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'leaderboard', code }),
          });
          const lbData = await lbRes.json().catch(() => ({}));
          if (lbRes.ok && lbData.ok) showChallengeLeaderboard(code, lbData.scores);
          return;
        }
        showInfoToast(res.status === 410 ? 'This challenge has ended.'
          : data.error === 'Challenge not found or expired'
          ? 'Challenge not found. Check the code and try again.'
          : 'Could not join challenge — check your connection and try again.');
        return;
      }
      // Backend challenge shape uses `questions`; local shape expects
      // `questionData` — normalize so startChallengeAttempt works either way.
      const challenge = { ...data.challenge, questionData: data.challenge.questions };
      window._currentChallengeCode = code;
      // Persist locally so this device has its own record of challenges it
      // joined, not just ones it created.
      {
        const challenges = loadSafe(QC_STORE, {});
        challenges[code] = { ...challenge, joinedAsParticipant: true };
        saveSafe(QC_STORE, challenges);
      }
      if (challenge.syncMode && challenge.syncMode !== 'anytime' && !challenge.startedAt) {
        _pendingChallenge = challenge;
        openWaitingRoom(code, challenge.creator === S.currentUser);
      } else if (challenge.syncMode && challenge.syncMode !== 'anytime' && challenge.startedAt) {
        showChallengeStartedNotice(code, challenge, challenge.startedAt);
      } else {
        startChallengeAttempt(challenge);
      }
    } finally {
      if (joinBtn) { joinBtn.disabled = false; joinBtn.textContent = 'Join →'; }
    }
  }

  function startOwnAttempt() {
    const code = window._currentChallengeCode;
    if (!code) return;
    const challenges = loadSafe(QC_STORE, {});
    const challenge  = challenges[code];
    if (!challenge) return;
    startChallengeAttempt(challenge);
  }

  function openWaitingRoom(code, isCreator) {
    _isWaitingRoomCreator = isCreator;
    document.getElementById('qcWaitingCodeDisplay').textContent = code;
    document.getElementById('qcForceStartBtn')?.classList.toggle('hidden', !isCreator);
    document.getElementById('qcEndChallengeBtn')?.classList.toggle('hidden', !isCreator);
    const readyBtn = document.getElementById('qcReadyBtn');
    if (readyBtn) { readyBtn.disabled = false; readyBtn.textContent = "✅ I'm Ready"; }
    showQcPanel('qcWaitingRoom');
    document.getElementById('quizChallengeModal').classList.remove('hidden');
    pollWaitingRoom(code);
  }

  function renderWaitingList(participants) {
    const list = document.getElementById('qcWaitingList');
    if (!list) return;
    const entries = Object.entries(participants || {});
    list.innerHTML = entries.map(([name, p]) => `
      <div class="qc-score-row">
        <span class="qc-rank">${p.ready ? '✅' : '⏳'}</span>
        <span class="qc-score-name">${safe(name)}${name === S.currentUser ? ' (you)' : ''}</span>
        <span class="qc-score-val">${p.ready ? 'Ready' : 'Waiting'}</span>
        ${_isWaitingRoomCreator && name !== S.currentUser
          ? `<button class="qc-pending-delete" data-name="${safe(name)}" style="margin-left:.4rem">Remove</button>` : ''}
      </div>
    `).join('') || '<p class="qc-sub">Waiting for people to join…</p>';

    list.querySelectorAll('button[data-name]').forEach(btn => {
      btn.addEventListener('click', () => removeParticipant(btn.dataset.name));
    });
  }

  function updateCountdownDisplay(msRemaining) {
    const el2 = document.getElementById('qcWaitingCountdown');
    if (!el2) return;
    if (msRemaining == null || msRemaining <= 0) { el2.classList.add('hidden'); return; }
    const totalSec = Math.ceil(msRemaining / 1000);
    const m = Math.floor(totalSec / 60), s = totalSec % 60;
    el2.textContent = `Auto-starts in ${m}:${String(s).padStart(2,'0')}`;
    el2.classList.remove('hidden');
  }

  async function pollWaitingRoom(code) {
    clearInterval(_waitingRoomTimer);
    clearInterval(_waitingRoomCountdownTicker);
    let localFirstReadyAt = null;
    let localScheduledAt = null;

    _waitingRoomCountdownTicker = setInterval(() => {
      if (localScheduledAt) updateCountdownDisplay(localScheduledAt - Date.now());
      else if (localFirstReadyAt) updateCountdownDisplay((localFirstReadyAt + WAITING_ROOM_TIMEOUT_MS) - Date.now());
    }, 1000);

    const tick = async () => {
      try {
        const res = await fetch(API_BASE + '/api/challenge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'status', code }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) return;

        if (data.ended) {
          clearInterval(_waitingRoomTimer);
          clearInterval(_waitingRoomCountdownTicker);
          document.getElementById('qcWaitingStatus').textContent = 'This challenge has ended.';
          document.getElementById('qcReadyBtn')?.classList.add('hidden');
          document.getElementById('qcForceStartBtn')?.classList.add('hidden');
          return;
        }

        renderWaitingList(data.participants);
        localFirstReadyAt = data.firstReadyAt || null;
        localScheduledAt  = data.scheduledStartAt || null;
        if (localScheduledAt) {
          document.getElementById('qcWaitingStatus').textContent = 'Challenge starts automatically at the scheduled time.';
        }

        if (data.startedAt) {
          clearInterval(_waitingRoomTimer);
          clearInterval(_waitingRoomCountdownTicker);
          showChallengeStartedNotice(code, _pendingChallenge, data.startedAt);
          return;
        }

        if (data.firstReadyAt && (Date.now() - data.firstReadyAt) > WAITING_ROOM_TIMEOUT_MS) {
          await fetch(API_BASE + '/api/challenge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'force_start', code }),
          });
        }
      } catch (err) { /* try again next tick */ }
    };

    tick();
    _waitingRoomTimer = setInterval(tick, 3000);
  }

  async function markReady() {
    const code = window._currentChallengeCode;
    if (!code) return;
    const btn = document.getElementById('qcReadyBtn');
    if (btn) { btn.disabled = true; btn.textContent = '✅ Waiting for others…'; }
    try {
      await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_ready', code, student: S.currentUser }),
      });
    } catch (err) {
      showInfoToast('Could not mark ready — check your connection.');
      if (btn) { btn.disabled = false; btn.textContent = "✅ I'm Ready"; }
    }
  }

  async function forceStartChallenge() {
    const code = window._currentChallengeCode;
    if (!code) return;
    try {
      await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'force_start', code }),
      });
    } catch (err) {
      showInfoToast('Could not start — check your connection.');
    }
  }

  async function removeParticipant(name) {
    const code = window._currentChallengeCode;
    if (!code) return;
    try {
      await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove_participant', code, student: name }),
      });
    } catch (err) {
      showInfoToast('Could not remove participant — check your connection.');
    }
  }

  async function endChallengeFromWaitingRoom() {
    const code = window._currentChallengeCode;
    if (!code) return;
    const ok = await showConfirmModal('End this challenge for everyone? Nobody will be able to join or continue it.', 'End Challenge', 'Cancel');
    if (!ok) return;
    await deleteChallenge(code);
    clearInterval(_waitingRoomTimer);
    clearInterval(_waitingRoomCountdownTicker);
    document.getElementById('quizChallengeModal').classList.add('hidden');
  }

  function startChallengeAttempt(challenge, startedAtOverride) {
    // A challenge is a one-shot comparison, not a retakeable practice set —
    // if this student already has a recorded score, show results instead.
    if (challenge.scores && challenge.scores[S.currentUser]) {
      showInfoToast("You've already completed this challenge — check the leaderboard for your result.");
      showChallengeLeaderboard(challenge.code, challenge.scores);
      return;
    }

    closeQuizChallenge();

    // Questions come directly from challenge.questionData (already fetched
    // at creation/join time) — no need to re-look-up EXAM_BANK[subject]
    // here, which matters now that a multi-subject challenge's `subject`
    // is a combined label like "Mathematics + Physics" that wouldn't match
    // any single EXAM_BANK key anyway.
    S.subject    = challenge.subject;
    S.subjects   = challenge.subjects || [challenge.subject];
    S.subjectRanges = challenge.subjectRanges || {};
    S.exam       = 'WAEC';
    S.mode       = 'exam';
    S.type       = 'objective';
    S.count      = challenge.questionData.length;
    S.questions  = challenge.questionData.map(q => ({...q, _type:'objective'}));
    S.answers    = new Array(S.questions.length).fill(null);
    S.flagged    = new Array(S.questions.length).fill(false);
    S.qTimings   = new Array(S.questions.length).fill(null);
    S.idx        = 0;
    S.reviewMode = false;
    S.showAnswer = false;
    S.inSession  = true;

    E.sbStudent.textContent = S.currentUser;
    E.sbSubject.textContent = S.subjects.length > 1 ? S.subject : (SUBJECTS[S.subject]?.name || S.subject);
    E.sbMode.textContent    = 'Challenge';
    E.sbExam.textContent    = S.exam;

    // Subject switcher — only for multi-subject challenges.
    const isMulti = S.subjects.length > 1;
    if (E.subjectSwitcher) E.subjectSwitcher.classList.toggle('hidden', !isMulti);
    if (isMulti) buildSubjectSwitcher();

    // Store challenge context so results can save score
    S._challengeCode = challenge.code;

    // Timer: for a challenge with a shared clock (ready/scheduled modes), a
    // late joiner resumes the already-ticking timer rather than getting a
    // fresh one.
    const startedAt = startedAtOverride || challenge.startedAt || Date.now();
    if (S.timerId) { clearInterval(S.timerId); S.timerId = null; }
    if (challenge.time > 0) {
      const elapsedSec = Math.max(0, Math.floor((Date.now() - startedAt) / 1000));
      S.timerSecs = Math.max(0, challenge.time * 60 - elapsedSec);
      if (E.timerCard) E.timerCard.style.display = 'block';
      if (E.qhMobileTimer) E.qhMobileTimer.classList.remove('hidden');
      runTimer();
    } else {
      S.timerSecs = 0;
      if (E.timerCard) E.timerCard.style.display = 'none';
      if (E.qhMobileTimer) E.qhMobileTimer.classList.add('hidden');
    }

    buildPills();
    renderQ();
    showScreen('quiz');
  }

  async function saveChallengeScore(score, total) {
    const code = S._challengeCode;
    if (!code) return;
    const pct = Math.round((score / total) * 100);

    // Keep a local copy too (covers the creator's own device offline)
    const challenges = loadSafe(QC_STORE, {});
    if (challenges[code]) {
      challenges[code].scores[S.currentUser] = { score, total, pct, time: new Date().toLocaleTimeString() };
      saveSafe(QC_STORE, challenges);
    }
    S._challengeCode = null;
    refreshChallengeBadgeState();

    let backendScores = null;
    try {
      const res = await fetch(API_BASE + '/api/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'submit', code, student: S.currentUser, score, total, pct }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) backendScores = data.scores;
    } catch (err) {
      // Non-fatal — the student's own result screen already showed their
      // score; the shared leaderboard just won't update this time.
    }

    const viewNow = await showConfirmModal('Challenge complete! View the leaderboard?', 'View', 'Not now');
    if (viewNow) showChallengeLeaderboard(code, backendScores);
  }

  function showChallengeLeaderboard(code, scoresOverride) {
    const challenges = loadSafe(QC_STORE, {});
    const localChallenge = challenges[code];
    const scores = scoresOverride || localChallenge?.scores;
    if (!scores) return;

    const list = document.getElementById('qcLeaderboardList');
    if (!list) return;

    const entries = Object.entries(scores).sort((a, b) => b[1].pct - a[1].pct);

    if (!entries.length) {
      list.innerHTML = '<p class="qc-empty">No scores yet — be the first!</p>';
    } else {
      list.innerHTML = entries.map(([name, data], i) => `
        <div class="qc-score-row ${name === S.currentUser ? 'qc-score-me' : ''}">
          <span class="qc-rank">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '#' + (i+1)}</span>
          <span class="qc-score-name">${safe(name)}${name === S.currentUser ? ' (you)' : ''}</span>
          <span class="qc-score-val">${data.score}/${data.total} · ${data.pct}%</span>
        </div>
      `).join('');
    }

    document.getElementById('quizChallengeModal').classList.remove('hidden');
    showQcPanel('qcLeaderboard');
  }

  function initContestNotify() {
    const btn  = document.getElementById('contestNotifyBtn');
    const note = document.getElementById('contestNoteText');

    // Collapse/expand logic
    const collapseBtn = document.getElementById('contestCollapseBtn');
    const expandBtn   = document.getElementById('contestExpandBtn');
    const expanded    = document.getElementById('contestExpanded');
    const collapsed   = document.getElementById('contestCollapsed');

    function collapseContest() {
      if (expanded) expanded.style.display = 'none';
      if (collapsed) collapsed.style.display = 'flex';
      // Only persist collapsed state if user has already clicked notify
      if (loadSafe('mea-contest-notify')) saveSafe('mea-contest-session-collapsed', true);
    }
    function expandContest() {
      if (expanded) expanded.style.display = '';
      if (collapsed) collapsed.style.display = 'none';
      saveSafe('mea-contest-session-collapsed', false);
    }

    // Only restore collapsed if they've notified AND previously collapsed
    if (loadSafe('mea-contest-notify') && loadSafe('mea-contest-session-collapsed')) {
      collapseContest();
    }

    if (collapseBtn) collapseBtn.addEventListener('click', collapseContest);
    if (expandBtn)   expandBtn.addEventListener('click', expandContest);

    // Auto-collapse when user starts a session (called from startSession)
    window._collapseContest = collapseContest;

    if (!btn) return;
    const already = loadSafe('mea-contest-notify');
    if (already) {
      btn.textContent  = '✓ You\'re on the list';
      btn.disabled     = true;
      btn.style.opacity = '0.7';
      if (note) note.textContent = 'We\'ll notify you when registration opens.';
      return;
    }
    btn.addEventListener('click', () => {
      if (!S.currentUser) {
        alert('Please log in first so we know who to notify.');
        return;
      }
      saveSafe('mea-contest-notify', { name: S.currentUser, date: new Date().toISOString() });
      btn.textContent   = '✓ You\'re on the list!';
      btn.disabled      = true;
      btn.style.opacity = '0.7';
      if (note) note.textContent = 'We\'ll notify you when registration opens. Tell your friends!';
    });
  }
  window._showChallengeLeaderboard = showChallengeLeaderboard;

  // Expose for result screen
  window.switchPaywallTab = function(tab) {
    ['individual','jamb','school'].forEach(t => {
      const panel = document.getElementById('paywall' + t.charAt(0).toUpperCase() + t.slice(1));
      const btn   = document.getElementById('tab'    + t.charAt(0).toUpperCase() + t.slice(1));
      if (panel) panel.classList.toggle('hidden', t !== tab);
      if (btn)   btn.classList.toggle('active',   t === tab);
    });
  };

  function redeemCode() {
    const code = (E.accessCodeInput.value||'').trim().toUpperCase();
    if (!code) { E.accessCodeInput.focus(); return; }
    const codes = {
      'MEA-DEMO-2025':  { days: 90,  tier: 'student' },
      'MEA-PLUS-DEMO':  { days: 90,  tier: 'plus'    },
      // 'WAEC-PROMO' and 'NECO-PROMO' — not in the official demo-code list,
      // disabled here since they'd have been visible to anyone via view-source
      // and grant free access. Re-enable only if this was an intentional campaign.
      'JAMB-PROMO':     { days: 90,  tier: 'jamb'    },
      'TEST7':          { days: 7,   tier: 'student' },
    };
    // ⚠️ These codes are still readable by anyone who views this file's source.
    // For long-lived or high-value codes, validate them server-side (via the
    // same Vercel API) instead of listing them in client JS.
    if (codes[code]) {
      grantAccess(codes[code].days, codes[code].tier);
    } else {
      E.accessCodeInput.style.borderColor = 'var(--red, #e55)';
      setTimeout(() => { E.accessCodeInput.style.borderColor = ''; }, 1500);
      alert('Invalid or expired code.');
    }
  }

  /* ════════ SHARE ════════ */
  /* ════════════════════════════════
     SESSION SHARING
  ════════════════════════════════ */

  // Store last result for sharing
  let _lastResult = null;
  let _lastQuestions = [];
  let _lastAnswers = [];

  function showSectionBNudge() {
    if (S.section !== 'A') return;
    const tabB = document.getElementById('sectionTabB');
    if (!tabB) return;

    // Remove any existing nudge
    document.getElementById('sectionBNudge')?.remove();

    // Get Section B tab position
    const rect = tabB.getBoundingClientRect();

    // Create overlay container
    const overlay = document.createElement('div');
    overlay.id = 'sectionBNudge';
    overlay.style.cssText = [
      'position:fixed','inset:0',
      'z-index:500',
      'pointer-events:none',
    ].join(';');

    // Highlight ring around Section B tab
    const ring = document.createElement('div');
    ring.style.cssText = [
      'position:absolute',
      `top:${rect.top - 4}px`,
      `left:${rect.left - 4}px`,
      `width:${rect.width + 8}px`,
      `height:${rect.height + 8}px`,
      'border:2.5px solid var(--gold,#d4af37)',
      'border-radius:10px',
      'animation:sectionBPulse 1s ease infinite',
      'pointer-events:none',
    ].join(';');

    // Tooltip card — centered on screen, pointing up to tab
    const tipTop  = rect.bottom + 16;
    const tipLeft = Math.max(16, Math.min(rect.left + rect.width/2 - 140, window.innerWidth - 296));

    const tip = document.createElement('div');
    tip.style.cssText = [
      'position:absolute',
      `top:${tipTop}px`,
      `left:${tipLeft}px`,
      'width:280px',
      'background:rgba(10,22,40,0.97)',
      'color:white',
      'border:1.5px solid var(--gold,#d4af37)',
      'border-radius:12px',
      'padding:.85rem 1rem',
      'font-size:.82rem','font-weight:500',
      'line-height:1.55',
      'text-align:center',
      'box-shadow:0 8px 32px rgba(0,0,0,.5)',
      'pointer-events:auto',
      'cursor:pointer',
    ].join(';');

    // Arrow pointing UP toward the tab
    const arrow = document.createElement('div');
    const arrowLeft = rect.left + rect.width/2 - tipLeft - 8;
    arrow.style.cssText = [
      'position:absolute',
      'top:-8px',
      `left:${Math.max(12, Math.min(arrowLeft, 252))}px`,
      'width:0','height:0',
      'border-left:8px solid transparent',
      'border-right:8px solid transparent',
      'border-bottom:8px solid var(--gold,#d4af37)',
    ].join(';');

    // Hand emoji that slides up toward the tab
    const hand = document.createElement('div');
    hand.style.cssText = [
      'position:absolute',
      `top:${rect.bottom + 8}px`,
      `left:${rect.left + rect.width/2 - 16}px`,
      'font-size:1.5rem',
      'animation:handSlideUp 1.2s ease infinite',
      'pointer-events:none',
    ].join(';');
    hand.textContent = '👆';

    tip.appendChild(arrow);
    tip.innerHTML += '<strong style="color:var(--gold,#d4af37);display:block;margin-bottom:.3rem">Did you know?</strong>Tap <strong>Section B</strong> to switch to Theory questions anytime — your Section A answers are saved!<br/><span style="font-size:.72rem;color:rgba(255,255,255,.5);margin-top:.4rem;display:block">Tap here or Section B to dismiss</span>';
    tip.insertBefore(arrow, tip.firstChild);

    overlay.appendChild(ring);
    overlay.appendChild(hand);
    overlay.appendChild(tip);
    document.body.appendChild(overlay);

    // Clicking tip or overlay dismisses
    tip.addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove();
    });

    // Auto dismiss after 7 seconds
    setTimeout(() => {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity .4s';
      setTimeout(() => overlay.remove(), 400);
    }, 7000);
  }

  function showGentleInlinePopup(msg, anchorEl) {
    document.querySelectorAll('.gentle-inline-popup').forEach(p => p.remove());
    const popup = document.createElement('div');
    popup.className = 'gentle-inline-popup';
    popup.textContent = msg;
    popup.style.cssText = [
      'background:rgba(10,22,40,0.97)',
      'color:white',
      'border:1.5px solid var(--gold)',
      'border-radius:var(--r-s)',
      'padding:.55rem .9rem',
      'font-size:.8rem','font-weight:600',
      'margin-bottom:.5rem',
      'text-align:center',
      'animation:gentlePopIn .18s ease',
    ].join(';');
    if (anchorEl) {
      anchorEl.parentNode.insertBefore(popup, anchorEl);
      anchorEl.scrollIntoView({ behavior:'smooth', block:'nearest' });
    }
    setTimeout(() => {
      popup.style.opacity = '0';
      popup.style.transition = 'opacity .3s';
      setTimeout(() => popup.remove(), 300);
    }, 3000);
  }

  function renderTimingCard() {
    const ta = S._timingAnalysis;
    if (!ta) return;
    const breakdown = document.getElementById('resultBreakdown');
    if (!breakdown) return;
    const existing = document.getElementById('timingCard');
    if (existing) existing.remove();
    const mins = Math.floor(ta.totalSec / 60);
    const secs = ta.totalSec % 60;
    const slowHtml = ta.slow.length ? `
      <div class="tc-slow-title">Questions you spent the most time on:</div>
      ${ta.slow.map(x => `<div class="tc-slow-row">
        <span class="tc-slow-q">Q${x.i+1}</span>
        <span class="tc-slow-text">${safe(x.q.question.substring(0,55))}…</span>
        <span class="tc-slow-time">${Math.round(x.dur/1000)}s</span>
      </div>`).join('')}` : '';

    const card = document.createElement('div');
    card.id = 'timingCard';
    card.className = 'timing-card';
    card.innerHTML = `
      <div class="tc-head">⏱ Session Timing</div>
      <div class="tc-stats">
        <div class="tc-stat"><span class="tc-val">${mins}m ${secs}s</span><span class="tc-label">Total time</span></div>
        <div class="tc-stat"><span class="tc-val">${ta.avg}s</span><span class="tc-label">Avg per question</span></div>
      </div>
      <div class="tc-verdict ${ta.avg < 60 ? 'tc-fast' : ta.avg < 90 ? 'tc-ok' : 'tc-slow'}">${ta.verdict}</div>
      ${slowHtml}
    `;
    breakdown.after(card);
  }

  function shareSession() {
    if (!_lastResult) return;
    const payload = {
      r: _lastResult,
      q: _lastQuestions.slice(0,20).map((q,i) => ({
        q: q.question,
        o: q.options || [],
        a: q.answer,
        ua: _lastAnswers[i],
        t: q._type,
        e: q.explanation || '',
      })),
    };
    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
    const url = window.location.origin + window.location.pathname + '?session=' + encoded;
    const text = `📊 ${_lastResult.student} scored ${_lastResult.pct !== null ? _lastResult.pct + '%' : 'Theory'} in ${_lastResult.subject} (${_lastResult.exam})\n\nSee my full session on My Exams App:\n${url}\n\nThink you can beat it? 💪`;

    if (navigator.share) {
      navigator.share({ title: 'My Exams App Result', text, url }).catch(() => {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => alert('📋 Result link copied! Paste in WhatsApp or anywhere.'));
    } else {
      prompt('Copy this link:', url);
    }
  }

  function checkForSharedSession() {
    const params = new URLSearchParams(window.location.search);
    const sessionData = params.get('session');
    if (!sessionData) return;
    history.replaceState(null, '', window.location.pathname);
    try {
      const payload = JSON.parse(decodeURIComponent(escape(atob(sessionData))));
      showSharedSession(payload);
    } catch(e) {
      console.warn('Could not parse shared session:', e);
    }
  }

  function showSharedSession(payload) {
    const r = payload.r;
    const qs = payload.q || [];
    const modal = document.getElementById('sharedSessionModal');
    if (!modal) return;

    const hasObj = r.pct !== null;
    const pct    = r.pct || 0;
    const grade  = !hasObj ? 'Theory' : pct>=75 ? 'Distinction' : pct>=60 ? 'Credit' : pct>=50 ? 'Pass' : 'Below Pass';
    const emoji  = !hasObj ? '📖' : pct>=75 ? '🏆' : pct>=60 ? '🎯' : pct>=50 ? '✅' : '💪';
    const color  = !hasObj ? '#666' : pct>=50 ? '#27ae60' : '#e74c3c';

    document.getElementById('ssEmoji').textContent = emoji;
    document.getElementById('ssScore').textContent = hasObj ? pct + '%' : 'Theory';
    document.getElementById('ssScore').style.color = color;
    document.getElementById('ssGrade').textContent = grade;
    document.getElementById('ssGrade').style.color = color;
    document.getElementById('ssMeta').innerHTML =
      `<strong>${safe(r.student)}</strong> · ${safe(r.subject)} · ${safe(r.exam)} · ${safe(r.mode)}` +
      `<br><span style="font-size:.8rem;color:#888">${safe(r.date)}</span>`;

    if (hasObj) {
      document.getElementById('ssStats').innerHTML =
        `<span class="ss-stat green">✓ ${r.correct} correct</span>` +
        `<span class="ss-stat red">✗ ${r.wrong} wrong</span>` +
        `<span class="ss-stat">⊘ ${r.skipped} skipped</span>`;
      document.getElementById('ssBarFill').style.width = pct + '%';
      document.getElementById('ssBarFill').style.background = color;
    }

    // Show first 5 questions as preview
    const preview = qs.slice(0, 5);
    document.getElementById('ssQuestions').innerHTML = preview.length ? `
      <div class="ss-qs-title">Session Preview (${preview.length} of ${qs.length} questions)</div>
      ${preview.map((q,i) => {
        const correct  = q.ua === q.a;
        const answered = q.ua !== null && q.ua !== undefined;
        const icon = !answered ? '⊘' : correct ? '✓' : '✗';
        const cls  = !answered ? 'ss-q-skip' : correct ? 'ss-q-correct' : 'ss-q-wrong';
        return `<div class="ss-q-row ${cls}">
          <span class="ss-q-icon">${icon}</span>
          <span class="ss-q-text">${safe(q.q.substring(0,80))}${q.q.length>80?'…':''}</span>
        </div>`;
      }).join('')}
    ` : '';

    // Store subject for try button
    document.getElementById('ssTryBtn').dataset.subject = r.subject;
    document.getElementById('ssTryBtn').addEventListener('click', () => {
      modal.classList.add('hidden');
      // Pre-select the subject on home screen
      S.subject = r.subject;
      showScreen('home');
      setTimeout(() => {
        const btn = document.querySelector(`.subject-btn[data-key="${r.subject}"]`);
        if (btn) btn.click();
      }, 300);
    });

    document.getElementById('ssClose').addEventListener('click', () => modal.classList.add('hidden'));
    modal.addEventListener('click', e => { if (e.target === modal) modal.classList.add('hidden'); });
    modal.classList.remove('hidden');
  }

  /* ════════════════════════════════
     AI EXPLANATIONS (Plus tier)
  ════════════════════════════════ */
  const SK_MEA_AI     = 'mea-ai-credits-v1';
  const MEA_AI_QUOTA  = 100; // per quarter

  function getMeaAICredits() {
    const qtr = getMeaQuarter();
    const d   = loadSafe(SK_MEA_AI);
    if (!d || d.quarter !== qtr) {
      saveSafe(SK_MEA_AI, { n: MEA_AI_QUOTA, quarter: qtr });
      return MEA_AI_QUOTA;
    }
    return d.n;
  }

  function useMeaAICredit() {
    const c = getMeaAICredits();
    if (c <= 0) return false;
    saveSafe(SK_MEA_AI, { n: c - 1, quarter: getMeaQuarter() });
    return true;
  }

  function getMeaQuarter() {
    const d = new Date();
    return `${d.getFullYear()}-Q${Math.ceil((d.getMonth()+1)/3)}`;
  }

  function updateMeaAICredits() {
    if (!E.meaAiCredits) return;
    const c = getMeaAICredits();
    E.meaAiCredits.textContent = `${c} credit${c===1?'':'s'} left`;
    E.meaAiCredits.style.color = c < 10 ? '#e74c3c' : '#27ae60';
  }

  async function triggerMeaAI(qType) {
    if (!(S.mode === 'practice' || S.reviewMode)) {
      showInfoToast('Teach Me is only available in Practice Mode or when reviewing your results.');
      return;
    }
    const isPlus = S.hasAccess && (loadSafe(SK.tier) === 'plus');
    if (!S.hasAccess) {
      showPaywall('upgrade');
      return;
    }
    if (!isPlus) {
      // Student Pass user — show upgrade prompt
      showPlusUpgradePrompt();
      return;
    }
    const credits = getMeaAICredits();
    if (credits <= 0) {
      alert(`You've used all ${MEA_AI_QUOTA} Teach Me credits for this quarter.\n\nTop up: ₦500 = 50 more explanations.`);
      return;
    }

    const q   = S.questions[S.idx];
    const ans = S.answers[S.idx];
    if (!q) return;

    // Show panel
    if (E.meaAiPanel) E.meaAiPanel.classList.remove('hidden');
    if (E.meaAiLoading) E.meaAiLoading.classList.remove('hidden');
    if (E.meaAiResponse) E.meaAiResponse.classList.add('hidden');
    updateMeaAICredits();

    let prompt = '';
    if (qType === 'objective') {
      const correctOpt  = q.options?.[q.answer] || q.answer;
      const studentOpt  = ans !== null && ans !== undefined ? (q.options?.[ans] || ans) : 'Did not answer';
      const wasCorrect  = ans === q.answer;
      prompt = `You are a WAEC/NECO exam tutor helping a Nigerian student prepare for their exams.

Question: ${q.question}
Options: ${(q.options||[]).map((o,i)=>String.fromCharCode(65+i)+'. '+o).join(' | ')}
Correct answer: ${correctOpt}
Student answered: ${studentOpt} (${wasCorrect ? 'CORRECT ✓' : 'WRONG ✗'})
Subject: ${SUBJECTS[S.subject]?.name || S.subject}
Exam: ${q.exam || S.exam}

Give a clear explanation in 3-4 sentences:
1. Why the correct answer is right — the key concept or principle
2. ${!wasCorrect ? "Why the student's choice was wrong and what trap they fell into" : "What makes this concept commonly tested in WAEC/NECO"}
3. A memory tip or rule to remember for the exam

Use plain English. Be encouraging. Keep it concise — this student is under exam pressure.`;
    } else {
      prompt = `You are a WAEC/NECO exam tutor helping a Nigerian student prepare.

Theory question: ${q.question}
Subject: ${SUBJECTS[S.subject]?.name || S.subject}
Exam: ${q.exam || S.exam}

The marking scheme awards points for: ${(q.markingScheme||[]).map(p=>p.point).join('; ')}

Explain in 4-5 sentences:
1. What the examiner is really asking for
2. The key points that must appear in a top-scoring answer
3. Common mistakes students make on this question
4. One examiner tip for maximising marks

Be specific to the Nigerian curriculum. Keep it practical and encouraging.`;
    }

    try {
      if (!useMeaAICredit()) {
        if (E.meaAiLoading) E.meaAiLoading.classList.add('hidden');
        alert('No AI credits remaining.');
        if (E.meaAiPanel) E.meaAiPanel.classList.add('hidden');
        return;
      }
      // ⚙️ Calls the same Vercel project as snap-and-mark — add a /api/teach
      // serverless function there that holds ANTHROPIC_API_KEY server-side
      // and forwards { prompt } to Claude. Calling api.anthropic.com directly
      // from the browser needs a key in the client bundle, which is visible
      // to anyone in the network tab — never do that for a paid feature.
      const res  = await fetch(API_BASE + '/api/teach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      const text = data.text || data.content?.map(c => c.text||'').join('') || 'Could not get explanation. Please try again.';

      if (E.meaAiLoading) E.meaAiLoading.classList.add('hidden');
      if (E.meaAiResponse) {
        E.meaAiResponse.innerHTML = `
          <div class="mea-ai-q">${safe(q.question.substring(0,90))}${q.question.length>90?'…':''}</div>
          <div class="mea-ai-text">${safe(text).replace(/\n/g,'<br/>')}</div>`;
        E.meaAiResponse.classList.remove('hidden');
      }
      updateMeaAICredits();
    } catch(err) {
      if (E.meaAiLoading) E.meaAiLoading.classList.add('hidden');
      if (E.meaAiResponse) {
        E.meaAiResponse.innerHTML = '<p style="color:#e74c3c;font-size:.85rem">Could not reach AI. Check your connection and try again.</p>';
        E.meaAiResponse.classList.remove('hidden');
      }
    }
  }

  /* ════════════════════════════════
     SNAP AND MARK
  ════════════════════════════════ */
  // ⚙️ Set your Vercel API URL here after deployment
  const SNAP_API_URL   = 'https://editoby-api.vercel.app/api/mark';
  const SK_SNAPS       = 'mea-snaps-v1';
  const SNAP_QUARTERLY = 50; // snaps per quarter for Student Pass

  function getSnapCredits() {
    const qtr = getMeaQuarter();
    const d   = loadSafe(SK_SNAPS);
    if (!d || d.quarter !== qtr) {
      saveSafe(SK_SNAPS, { n: SNAP_QUARTERLY, quarter: qtr });
      return SNAP_QUARTERLY;
    }
    return d.n;
  }

  function useSnapCredit() {
    const c = getSnapCredits();
    if (c <= 0) return false;
    saveSafe(SK_SNAPS, { n: c - 1, quarter: getMeaQuarter() });
    return true;
  }

  function updateSnapCreditsBadge() {
    if (!E.snapCreditsBadge) return;
    const c = getSnapCredits();
    E.snapCreditsBadge.textContent = `${c} snap${c===1?'':'s'} left this quarter`;
    E.snapCreditsBadge.style.color = c < 5 ? '#e74c3c' : 'var(--text-dim)';
  }

  function triggerSnap() {
    if (!S.hasAccess) { showPaywall('upgrade'); return; }
    const credits = getSnapCredits();
    if (credits <= 0) {
      alert('You have used all your snap credits for this quarter.\n\nTop up: ₦300 = 10 more snaps.');
      return;
    }
    // Open file picker — on mobile this triggers camera
    if (E.snapFileInput) E.snapFileInput.click();
  }

  function handleSnapFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    // Reset input so same file can be reselected
    e.target.value = '';

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file.');
      return;
    }

    // Compress then send
    compressImage(file, 800, 0.75)
      .then(compressed => sendToMark(compressed))
      .catch(err => {
        console.error('Compression error:', err);
        alert('Could not process image. Please try again.');
      });
  }

  function compressImage(file, maxWidth, quality) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = ev => {
        const img = new Image();
        img.onerror = reject;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let w = img.width;
          let h = img.height;

          // Scale down if wider than maxWidth
          if (w > maxWidth) {
            h = Math.round(h * (maxWidth / w));
            w = maxWidth;
          }

          canvas.width  = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');

          // White background (prevents transparency issues)
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);

          // Export as JPEG
          const dataUrl = canvas.toDataURL('image/jpeg', quality);
          const base64  = dataUrl.split(',')[1];

          // Log compression ratio for debugging
          const origKB = Math.round(file.size / 1024);
          const compKB = Math.round(base64.length * 0.75 / 1024);
          console.log(`Snap compressed: ${origKB}KB → ${compKB}KB`);

          resolve({ base64, mediaType: 'image/jpeg', sizeKB: compKB });
        };
        img.src = ev.target.result;
      };
      reader.readAsDataURL(file);
    });
  }

  async function sendToMark({ base64, mediaType }) {
    const q = S.questions[S.idx];
    if (!q || q._type !== 'theory') return;

    // Show processing overlay
    if (E.snapProcessing) E.snapProcessing.classList.remove('hidden');

    if (!useSnapCredit()) {
      if (E.snapProcessing) E.snapProcessing.classList.add('hidden');
      alert('No snap credits remaining.');
      return;
    }
    updateSnapCreditsBadge();

    const scheme = (q.markingScheme || []).map(s => ({
      point: s.point,
      marks: s.marks || 1,
    }));
    const totalMarks = scheme.reduce((sum, s) => sum + s.marks, 0);

    try {
      const res = await fetch(SNAP_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image:      base64,
          mediaType,
          question:   q.question,
          scheme,
          totalMarks,
          subject:    SUBJECTS[S.subject]?.name || S.subject,
          examBody:   q.exam || S.exam,
        }),
      });

      if (E.snapProcessing) E.snapProcessing.classList.add('hidden');

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        if (err.code === 'IMAGE_TOO_LARGE') {
          alert('Image is too large even after compression. Please try again with better lighting to avoid needing maximum quality.');
        } else {
          alert(err.error || 'Could not reach marking server. Check your connection.');
        }
        return;
      }

      const result = await res.json();
      showSnapResult(result);

    } catch (err) {
      if (E.snapProcessing) E.snapProcessing.classList.add('hidden');
      console.error('Snap API error:', err);
      alert('Could not reach the marking server. Check your internet connection and try again.');
    }
  }

  function showSnapResult(result) {
    const { awarded, total, percent, grade, feedback, examinerNote, breakdown, handwritingWarning } = result;

    const color = percent >= 60 ? '#27ae60' : percent >= 40 ? '#e67e22' : '#e74c3c';

    if (E.snapResultScore) {
      E.snapResultScore.textContent = `${awarded}/${total}`;
      E.snapResultScore.style.color = color;
    }
    if (E.snapResultGrade) {
      E.snapResultGrade.textContent = grade;
      E.snapResultGrade.style.color = color;
    }
    if (E.snapResultPct) {
      E.snapResultPct.textContent = `${percent}%`;
      E.snapResultPct.style.color = color;
    }

    // Handwriting warning
    if (E.snapHwWarning) {
      E.snapHwWarning.classList.toggle('hidden', !handwritingWarning);
    }

    // Feedback
    if (E.snapFeedback) E.snapFeedback.textContent = feedback;

    // Breakdown
    if (E.snapBreakdown && breakdown?.length) {
      E.snapBreakdown.innerHTML = breakdown.map(b => {
        const full = b.awarded >= b.maxMarks;
        const none = b.awarded === 0;
        const cls  = full ? 'sbr-full' : none ? 'sbr-none' : 'sbr-part';
        const icon = full ? '✓' : none ? '✗' : '½';
        return `<div class="snap-breakdown-row ${cls}">
          <span class="sbr-icon">${icon}</span>
          <div class="sbr-body">
            <div class="sbr-point">${safe(b.point)}</div>
            <div class="sbr-comment">${safe(b.comment || '')}</div>
          </div>
          <span class="sbr-marks">${b.awarded}/${b.maxMarks}</span>
        </div>`;
      }).join('');
    }

    // Examiner note
    if (E.snapExaminerNote && examinerNote) {
      E.snapExaminerNote.innerHTML = `📌 <strong>Remember:</strong> ${safe(examinerNote)}`;
    }

    if (E.snapResultModal) E.snapResultModal.classList.remove('hidden');

    // Practice mode — mark as snapped and reveal marking scheme + model answer
    if (S.mode === 'practice' && !S.reviewMode) {
      S.answers[S.idx] = 'snapped';
      S.showAnswer = true;
      // Re-render theory panel to reveal full marking scheme
      const q = S.questions[S.idx];
      if (q && q._type === 'theory') renderTheory(q);
    }
  }

  function showPlusUpgradePrompt() {
    const modal = document.getElementById('exitConfirmModal');
    const icon  = document.getElementById('exitModalIcon');
    const title = document.getElementById('exitModalTitle');
    const sub   = document.getElementById('exitModalSub');
    const stay  = document.getElementById('exitModalStay');
    const leave = document.getElementById('exitModalLeave');
    if (!modal) { showPaywall('upgrade'); return; }

    icon.textContent  = '🧠';
    title.textContent = '"Teach Me" is a Plus Feature';
    sub.textContent   = 'Tap "Teach Me" on any question and AI breaks it down — the concept, the trap, a memory tip. Upgrade to Student Pass Plus for ₦3,500/quarter.';

    const newStay  = stay.cloneNode(true);
    const newLeave = leave.cloneNode(true);
    stay.parentNode.replaceChild(newStay, stay);
    leave.parentNode.replaceChild(newLeave, leave);

    document.getElementById('exitModalStay').textContent  = 'Not Now';
    document.getElementById('exitModalLeave').textContent = 'Upgrade to Plus — ₦3,500 →';
    document.getElementById('exitModalStay').style.cssText  = '';
    document.getElementById('exitModalStay').addEventListener('click',  () => modal.classList.add('hidden'));
    document.getElementById('exitModalLeave').addEventListener('click', () => {
      modal.classList.add('hidden');
      handlePayment('plus', 'quarterly');
    });
    modal.classList.remove('hidden');
  }

  /* ════════ BACK BUTTON WARNING TOAST ════════ */
  let _backToastTimer = null;

  function showBackWarningToast() {
    let toast = document.getElementById('backWarningToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'backWarningToast';
      toast.style.cssText = `
        position:fixed; bottom:5rem; left:50%; transform:translateX(-50%);
        background:#0a1628; color:white; border:1.5px solid #d4af37;
        border-radius:10px; padding:.75rem 1.25rem;
        font-family:var(--sans,sans-serif); font-size:.82rem; font-weight:500;
        text-align:center; z-index:9999; max-width:320px; width:calc(100% - 2rem);
        box-shadow:0 4px 20px rgba(0,0,0,.4); line-height:1.5;
        animation:toastSlideUp .25s ease;
      `;
      document.body.appendChild(toast);
    }
    const isExam = S.mode === 'exam';
    toast.innerHTML = isExam
      ? '⚠️ <strong>Press back again to exit exam.</strong><br>Use <strong>← Prev / Next →</strong> to navigate questions.'
      : '← <strong>Press back again to exit session.</strong><br>Use <strong>← Prev / Next →</strong> to navigate questions.';
    toast.style.display = 'block';

    if (_backToastTimer) clearTimeout(_backToastTimer);
    _backToastTimer = setTimeout(hideBackWarningToast, 3000);
  }

  function hideBackWarningToast() {
    const toast = document.getElementById('backWarningToast');
    if (toast) toast.style.display = 'none';
    if (_backToastTimer) { clearTimeout(_backToastTimer); _backToastTimer = null; }
  }

  /* ════════ SECTION SWITCHING ════════ */
  function showSectionEndChoice(fromSection) {
    const modal = document.getElementById('sectionEndModal');
    const sub   = document.getElementById('sectionEndSub');
    if (!modal) { showSectionTransition(); return; }

    const isA = fromSection === 'A';
    const count = isA ? S.sectionA.length : S.sectionB.length;
    const type  = isA ? 'Objective' : 'Theory';
    const label = isA ? 'Section A' : 'Section B';
    sub.textContent = `You have finished ${label} (${count} ${type} questions). Choose what to do next — your answers in both sections are saved.`;

    // Update icon and title
    document.querySelector('#sectionEndModal .exit-modal-icon').textContent = isA ? '📋' : '📝';
    document.querySelector('#sectionEndModal .exit-modal-title').textContent = `${label} Complete`;

    modal.classList.remove('hidden');

    const closeBtn   = document.getElementById('sectionEndClose');
    const remainBtn  = document.getElementById('seRemainBtn');
    const goBBtn     = document.getElementById('seGoBBtn');
    const finishBtn  = document.getElementById('seFinishBtn');

    // Clone all to clear old listeners
    const newClose  = closeBtn.cloneNode(true);
    const newRemain = remainBtn.cloneNode(true);
    const newGoB    = goBBtn.cloneNode(true);
    const newFinish = finishBtn.cloneNode(true);
    closeBtn.parentNode.replaceChild(newClose, closeBtn);
    remainBtn.parentNode.replaceChild(newRemain, remainBtn);
    goBBtn.parentNode.replaceChild(newGoB, goBBtn);
    finishBtn.parentNode.replaceChild(newFinish, finishBtn);

    const hide = () => modal.classList.add('hidden');

    // Close — stay in Section A, card dismisses, can reappear if they tap Next again
    document.getElementById('sectionEndClose').addEventListener('click', hide);

    // Remain in Section A — same as close, explicit wording
    const remainBtn2  = document.getElementById('seRemainBtn');
    const goBBtn2     = document.getElementById('seGoBBtn');
    if (remainBtn2) remainBtn2.textContent = fromSection === 'A'
      ? '📖 Remain in Section A — Review/Complete'
      : '📖 Remain in Section B — Review/Complete';
    if (goBBtn2) goBBtn2.textContent = fromSection === 'A'
      ? '📋 Go to Section B →'
      : '📋 Go to Section A ←';

    document.getElementById('seRemainBtn').addEventListener('click', hide);

    // Switch to other section
    document.getElementById('seGoBBtn').addEventListener('click', () => {
      hide();
      switchSection(fromSection === 'A' ? 'B' : 'A');
    });

    // Finish — submit current state across both sections now
    document.getElementById('seFinishBtn').addEventListener('click', () => {
      hide();
      confirmSubmit();
    });
  }

  function showSectionTransition() {
    // Show a modal prompting student to move to Section B
    const modal = document.getElementById('exitConfirmModal');
    const icon  = document.getElementById('exitModalIcon');
    const title = document.getElementById('exitModalTitle');
    const sub   = document.getElementById('exitModalSub');
    const stay  = document.getElementById('exitModalStay');
    const leave = document.getElementById('exitModalLeave');
    if (!modal) { switchSection('B'); return; }

    icon.textContent  = '📋';
    title.textContent = 'Section A Complete';
    sub.textContent   = 'You have reached the end of Section A (Objectives). Move to Section B (Theory) or stay to review your answers.';
    leave.textContent = 'Go to Section B →';
    const stayBtn  = stay.cloneNode(true);
    const leaveBtn = leave.cloneNode(true);
    stay.parentNode.replaceChild(stayBtn, stay);
    leave.parentNode.replaceChild(leaveBtn, leave);
    document.getElementById('exitModalStay').textContent  = 'Stay in Section A';
    document.getElementById('exitModalLeave').textContent = 'Go to Section B →';
    document.getElementById('exitModalStay').addEventListener('click',  () => modal.classList.add('hidden'));
    document.getElementById('exitModalLeave').addEventListener('click', () => {
      modal.classList.add('hidden');
      switchSection('B');
    });
    modal.classList.remove('hidden');
  }

  function switchSection(section) {
    if (section === S.section) return;
    // Save answers for current section before switching
    if (S.section === 'A') {
      S.sectionA = S.questions.map((q, i) => ({...q, _savedAns: S.answers[i], _savedFlag: S.flagged[i]}));
    } else {
      S.sectionB = S.questions.map((q, i) => ({...q, _savedAns: S.answers[i], _savedFlag: S.flagged[i]}));
    }
    S.section = section;
    const newPool = section === 'A' ? S.sectionA : S.sectionB;
    // Explicitly preserve _type when cleaning up saved fields
    S.questions = newPool.map(q => {
      const c = {...q};
      delete c._savedAns;
      delete c._savedFlag;
      // Ensure _type is always set correctly
      if (!c._type) c._type = section === 'A' ? 'objective' : 'theory';
      return c;
    });
    S.answers   = newPool.map(q => q._savedAns !== undefined ? q._savedAns : null);
    S.flagged   = newPool.map(q => q._savedFlag || false);
    S.idx = 0;
    S.showAnswer = false;
    buildPills();
    renderQ();
    if (E.sectionTabA) E.sectionTabA.classList.toggle('active', section === 'A');
    if (E.sectionTabB) E.sectionTabB.classList.toggle('active', section === 'B');
  }

  function shareApp() {
    const url  = window.location.href;
    const text = '🎓 Preparing for WAEC/NECO? Try My Exams App!\nPast questions + model answers for 15 subjects + snap-and-mark theory.\n₦2,500 for 3 months — early access at ₦2,000.\n\n'+url;
    if (navigator.share) navigator.share({title:'My Exams App',text,url}).catch(()=>{});
    else if (navigator.clipboard) navigator.clipboard.writeText(text)
      .then(()=>alert('📋 Copied! Paste in WhatsApp or SMS.'));
    else prompt('Copy and share:',text);
  }

  /* ════════ SIDEBAR ════════ */
  function openSidebar()  { E.quizSidebar.classList.add('sidebar-open'); E.sidebarBackdrop.classList.remove('hidden'); }
  function closeSidebar() { E.quizSidebar.classList.remove('sidebar-open'); E.sidebarBackdrop.classList.add('hidden'); }

  /* ════════ SCREENS ════════ */
  function showScreen(name) {
    ['home','quiz','result','class','teacherDash','parentDash'].forEach(n => {
      document.getElementById(n+'Screen').classList.toggle('active', n===name);
    });
    window.scrollTo(0,0);
    if (name==='home') { renderHistory(); refreshStats(); renderStreak(); refreshUpgradeBar(); }
    if (name==='result') { renderResultTeaser(); }
    if (name==='quiz' && !S.hasAccess) { scheduleTeaserToast(); }
    const qcBtn = document.getElementById('quizChallengeBtn');
    if (qcBtn) qcBtn.classList.toggle('hidden', name === 'quiz');

    // Hash-based navigation — reliable on Chrome mobile/PC and Firefox
    if (name === 'quiz' || name === 'result') {
      // Set hash without triggering hashchange (we only want it to trigger on back)
      history.pushState(null, '', window.location.pathname + '#' + name);
    } else {
      // Going home — clear hash
      history.pushState(null, '', window.location.pathname);
    }
  }

  /* ════════ UPGRADE BAR ════════ */
  function renderPlanBadge() {
    const badge = document.getElementById('planBadge');
    if (!badge) return;
    if (!S.currentUser) { badge.classList.add('hidden'); return; }

    const tier   = loadSafe(SK.tier) || 'free';
    const access = loadSafe(SK.access);
    const active = access?.expires && new Date(access.expires) > new Date();
    const exp    = active ? new Date(access.expires) : null;
    const expStr = exp ? exp.toLocaleDateString('en-NG', {day:'numeric',month:'short',year:'numeric'}) : '';

    if (!active) {
      badge.innerHTML = `<span>🆓 Free Trial</span><button class="plan-badge-upgrade" onclick="showPaywall('upgrade')">Upgrade →</button>`;
      badge.className = 'plan-badge plan-free';
    } else if (tier === 'plus') {
      badge.innerHTML = `<span>⭐ Student Pass Plus${expStr ? ' · expires ' + expStr : ''}</span><button class="plan-badge-renew" onclick="handlePayment('plus','quarterly')">Renew →</button>`;
      badge.className = 'plan-badge plan-plus';
    } else {
      // Student Pass — offer upgrade to Plus
      badge.innerHTML = `<span>✅ Student Pass${expStr ? ' · expires ' + expStr : ''}</span><button class="plan-badge-upgrade" onclick="showPlusUpgradePrompt()">Upgrade to Plus →</button>`;
      badge.className = 'plan-badge plan-student';
    }
    badge.classList.remove('hidden');
  }

  function refreshUpgradeBar() {
    const qcBtn = document.getElementById('quizChallengeBtn');
    if (!E.upgradeBar) return;
    if (S.hasAccess) {
      E.upgradeBar.style.display = 'none';
      if (qcBtn && S.currentUser) qcBtn.classList.remove('hidden');
      return;
    }
    // Show challenge button to free users too — they get paywall on click
    // It acts as another conversion touchpoint
    if (qcBtn && S.currentUser) qcBtn.classList.remove('hidden');
    E.upgradeBar.style.display = '';
    const remaining = Math.max(0, FREE_TRIAL_LIMIT - S.freeUsed);
    const msgs = [
      `⚡ ${remaining} free question${remaining===1?'':'s'} left — unlock unlimited access from ₦2,000`,
      `🧠 Tap Teach Me you got it wrong — Student Pass Plus explains every answer`,
      `📸 Snap your theory answers and get marked instantly — Student Pass`,
      `🏆 WAEC & NECO prep — Teach Me, snap marking, community quiz from ₦2,000`,
      `🔓 Unlimited sessions · All 15 subjects · Year-by-year papers — Student Pass`,
      `💡 "Why is this correct?" — Teach Me for your weak areas. Plus tier ₦3,500.`,
    ];
    const idx = Math.floor(Date.now() / 30000) % msgs.length;
    if (E.upgradeBarText) E.upgradeBarText.textContent = msgs[idx];
  }

  /* ════════ RESULT TEASER ════════ */
  const RESULT_TEASERS = [
    {
      icon: '🧠',
      title: 'Got questions wrong? Tap Teach Me.',
      sub:   'Student Pass Plus — tap "Teach Me" on any question. AI breaks down the concept, the trap, the memory tip. ₦3,500/quarter.'
    },
    {
      icon: '📸',
      title: 'Snap your theory answers. Get marked in seconds.',
      sub:   'Student Pass includes 50 snap-and-mark credits. No other exam prep app in Nigeria does this.'
    },
    {
      icon: '💡',
      title: '"Teach Me" — tap to understand any answer',
      sub:   'Teach Me on Tap "Teach Me" and AI breaks down every question — the concept, the trap, the memory tip. Built for WAEC & NECO.'
    },
    {
      icon: '📚',
      title: 'You just scratched the surface.',
      sub:   'Subscribers access all 15 subjects, all years — WAEC, NECO, GCE and NABTEB. Unlimited sessions.'
    },
    {
      icon: '🎯',
      title: 'Serious students subscribe.',
      sub:   'Early access at ₦2,000/quarter — only 100 spots. Teach Me, snap marking, community quiz. All in.'
    },
    {
      icon: '📅',
      title: 'Drill past questions year by year.',
      sub:   'Filter by 2019, 2020, 2021, 2022 or 2023 — or mix all years. Subscribers unlock every year.'
    },
    {
      icon: '🏆',
      title: 'Challenge your friends. See who scores higher.',
      sub:   'Community quiz lets paid subscribers create a challenge, share the code on WhatsApp, and compare scores.'
    },
  ];

  function renderResultTeaser() {
    if (!E.resultUpgradTeaser) return;
    if (S.hasAccess) { E.resultUpgradTeaser.style.display = 'none'; return; }
    E.resultUpgradTeaser.style.display = '';
    const t = RESULT_TEASERS[Math.floor(Math.random() * RESULT_TEASERS.length)];
    const iconEl = E.resultUpgradTeaser.querySelector('.rut-icon');
    if (iconEl) iconEl.textContent = t.icon;
    if (E.rutTitle) E.rutTitle.textContent = t.title;
    const subEl = E.resultUpgradTeaser.querySelector('.rut-sub');
    if (subEl) subEl.textContent = t.sub;
  }

  /* ════════ TEASER TOAST (mid-session) ════════ */
  const SESSION_TEASERS = [
    '🧠 Tap Teach Me you got that wrong — Student Pass Plus explains every answer. ₦3,500/quarter.',
    '💡 "Teach Me" — tap to understand any answer — Teach Me built for WAEC & NECO. Upgrade to Plus.',
    '📸 Snap your theory answer and get it marked against the official scheme — Student Pass.',
    '⚡ Unlimited sessions across all 15 subjects from ₦2,000 — early access, 100 spots only.',
    '🏆 Challenge a friend on this subject — subscribe and create a quiz challenge now.',
    '🔐 Lock in early access at ₦2,000/quarter before the price goes up. Limited spots left.',
    '📅 Filter by exam year — drill 2023 WAEC only, or mix all years. Subscribers unlock everything.',
  ];

  let _teaserTimer = null;

  function scheduleTeaserToast() {
    if (S.hasAccess) return;
    if (_teaserTimer) clearTimeout(_teaserTimer);
    // Show at question 5 or after 90 seconds — whichever comes first
    _teaserTimer = setTimeout(() => {
      if (!S.hasAccess && S.inSession) showTeaserToast();
    }, 90000);
  }

  function showTeaserToast() {
    if (!E.teaserToast) return;
    const msg = SESSION_TEASERS[Math.floor(Math.random() * SESSION_TEASERS.length)];
    if (E.teaserToastText) E.teaserToastText.textContent = msg;
    E.teaserToast.classList.remove('hidden');
    // Auto-hide after 8 seconds
    setTimeout(hideTeaserToast, 8000);
  }

  function hideTeaserToast() {
    if (E.teaserToast) E.teaserToast.classList.add('hidden');
  }

  /* ════════ UTILS ════════ */
  /* ════════ INFO TOAST (replaces native alert() for simple notices) ════════ */
  function showInfoToast(message) {
    let toast = document.getElementById('meaInfoToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'meaInfoToast';
      toast.style.cssText = `
        position:fixed; bottom:5rem; left:50%; transform:translateX(-50%);
        background:#0a1628; color:white; border:1.5px solid var(--gold,#d4af37);
        border-radius:10px; padding:.75rem 1.25rem;
        font-family:var(--sans,sans-serif); font-size:.82rem; font-weight:500;
        text-align:center; z-index:9999; max-width:320px; width:calc(100% - 2rem);
        box-shadow:0 4px 20px rgba(0,0,0,.4); line-height:1.5;
      `;
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.display = 'block';
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => { toast.style.display = 'none'; }, 3500);
  }

  function safe(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function shuffle(a) {
    const r=[...a];
    for(let i=r.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[r[i],r[j]]=[r[j],r[i]];}
    return r;
  }
  function saveSafe(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
  function loadSafe(k,d=null){try{const v=localStorage.getItem(k);return v!==null?JSON.parse(v):d;}catch(e){return d;}}
  function todayStr(){return new Date().toISOString().slice(0,10);}

  // Inline onclick="..." attributes (in index.html and in HTML strings built
  // by this file) can only see truly global functions — anything defined
  // inside this closure is invisible to them, causing "X is not defined"
  // errors. Expose every function referenced that way here.
  window.showPlusUpgradePrompt = showPlusUpgradePrompt;
  window.handlePayment         = handlePayment;
  window.showPaywall           = showPaywall;
  window.upgradeToPlus         = upgradeToPlus;

  init();
})();
